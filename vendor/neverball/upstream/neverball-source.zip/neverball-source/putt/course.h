#ifndef COURSE_H
#define COURSE_H

/*---------------------------------------------------------------------------*/

#define COURSE_FILE "courses.txt"
#define MAXCRS 16

void course_init(void);
void course_free(void);

int  course_exists(int);
int  course_count(void);
int  course_find(const char *);
int  course_bundle_index(const char *);
void course_goto(int);
int  course_curr(void);
void course_rand(void);

const char *course_name(int);
const char *course_desc(int);
const char *course_shot(int);

/*---------------------------------------------------------------------------*/

#endif
