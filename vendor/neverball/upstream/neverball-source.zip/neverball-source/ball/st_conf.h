#ifndef ST_CONF_H
#define ST_CONF_H

#include "state.h"

extern struct state st_conf;
extern struct state st_null;

extern struct state st_conf_gameplay;
extern struct state st_conf_controls;
extern struct state st_conf_touch;

extern struct state st_conf_video;
extern struct state st_conf_display;

#endif
