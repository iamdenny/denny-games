/*
 * Copyright (C) 2003 Robert Kooima
 *
 * NEVERBALL is  free software; you can redistribute  it and/or modify
 * it under the  terms of the GNU General  Public License as published
 * by the Free  Software Foundation; either version 2  of the License,
 * or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT  ANY  WARRANTY;  without   even  the  implied  warranty  of
 * MERCHANTABILITY or  FITNESS FOR A PARTICULAR PURPOSE.   See the GNU
 * General Public License for more details.
 */

#include "gui.h"
#include "transition.h"
#include "hud.h"
#include "geom.h"
#include "ball.h"
#include "part.h"
#include "audio.h"
#include "config.h"
#include "video.h"
#include "common.h"
#include "version.h"
#include "lang.h"

#include "game_common.h"
#include "game_client.h"
#include "game_server.h"

#include "st_conf.h"
#include "st_title.h"
#include "st_common.h"
#include "st_name.h"
#include "st_ball.h"
#include "st_shared.h"

extern const char TITLE[];
extern const char ICON[];

/*---------------------------------------------------------------------------*/

enum
{
    CONF_VIDEO = GUI_LAST,
    CONF_GAMEPLAY,
    CONF_CONTROLS,
    CONF_LANGUAGE,
    CONF_SOUND_VOLUME,
    CONF_MUSIC_VOLUME,
    CONF_PLAYER,
    CONF_BALL
};

static int music_id[11];
static int sound_id[11];

static struct state *conf_back;

static int conf_action(int tok, int val)
{
    int sound = config_get_d(CONFIG_SOUND_VOLUME);
    int music = config_get_d(CONFIG_MUSIC_VOLUME);
    int r = 1;

    audio_play(AUD_MENU, 1.0f);

    switch (tok)
    {
    case GUI_BACK:
        exit_state(conf_back ? conf_back : &st_title);
        conf_back = NULL;
        break;

    case CONF_VIDEO:
        goto_state(&st_video);
        break;

    case CONF_GAMEPLAY:
        goto_state(&st_conf_gameplay);
        break;

    case CONF_CONTROLS:
        goto_state(&st_conf_controls);
        break;

    case CONF_LANGUAGE:
        goto_state(&st_lang);
        break;

    case CONF_PLAYER:
        goto_name(&st_conf, &st_conf, 1);
        break;

    case CONF_BALL:
        goto_state(&st_ball);
        break;

    case CONF_SOUND_VOLUME:
        config_set_d(CONFIG_SOUND_VOLUME, val);
        audio_volume(val, music);
        audio_play(AUD_BUMPM, 1.f);

        gui_toggle(sound_id[val]);
        gui_toggle(sound_id[sound]);
        break;

    case CONF_MUSIC_VOLUME:
        config_set_d(CONFIG_MUSIC_VOLUME, val);
        audio_volume(sound, val);
        audio_play(AUD_BUMPM, 1.f);

        gui_toggle(music_id[val]);
        gui_toggle(music_id[music]);

        break;
    }

    return r;
}

static int conf_gui(void)
{
    int root_id;

    /* Initialize the configuration GUI. */

    if ((root_id = gui_root()))
    {
        int id;

        if ((id = gui_vstack(root_id)))
        {
            int sound = config_get_d(CONFIG_SOUND_VOLUME);
            int music = config_get_d(CONFIG_MUSIC_VOLUME);

            const char *player = config_get_s(CONFIG_PLAYER);
            const char *ball   = config_get_s(CONFIG_BALL_FILE);

            int name_id, ball_id, lang_id;

            conf_header(id, _("Options"), GUI_BACK);

            conf_state(id, _("Graphics"), _("Configure"), CONF_VIDEO);
            conf_state(id, _("Gameplay"), _("Configure"), CONF_GAMEPLAY);
            conf_state(id, _("Controls"), _("Configure"), CONF_CONTROLS);

            gui_space(id);

            conf_slider(id, _("Sound Volume"), CONF_SOUND_VOLUME, sound,
                        sound_id, ARRAYSIZE(sound_id));
            conf_slider(id, _("Music Volume"), CONF_MUSIC_VOLUME, music,
                        music_id, ARRAYSIZE(music_id));

            gui_space(id);

            name_id = conf_state(id, _("Player Name"), " ", CONF_PLAYER);
            ball_id = conf_state(id, _("Ball Model"), " ", CONF_BALL);
            lang_id = conf_state(id, _("Language"), " ", CONF_LANGUAGE);

            gui_layout(id, 0, 0);

            gui_set_trunc(lang_id, TRUNC_TAIL);
            gui_set_trunc(name_id, TRUNC_TAIL);
            gui_set_trunc(ball_id, TRUNC_TAIL);

            gui_set_label(name_id, player);
            gui_set_label(ball_id, base_name(ball));

            if (*config_get_s(CONFIG_LANGUAGE))
                gui_set_label(lang_id, lang_name(&curr_lang));
            else
                gui_set_label(lang_id, _("Default"));
        }

        if ((id = gui_vstack(root_id)))
        {
            gui_label(id, "Neverball " VERSION, GUI_TNY, gui_wht, gui_wht);
            gui_multi(id, _(
                "Copyright © 2025 Neverball authors\n"
                "Neverball is free software available under the terms of GPL v2 or later."
            ), GUI_TNY, gui_wht, gui_wht);

            gui_clr_rect(id);
            gui_layout(id, 0, -1);
        }
    }

    return root_id;
}

static void conf_bg_paint(float t)
{
    if (game_server_state())
    {
        game_client_draw(0, t);
    }
    else
    {
        video_push_persp((float) config_get_d(CONFIG_VIEW_FOV), 0.1f, FAR_DIST);
        {
            back_draw_easy();
        }
        video_pop_matrix();
    }
}

static int conf_enter(struct state *st, struct state *prev, int intent)
{
    if (!conf_back)
        conf_back = prev;

    if (!game_server_state())
    {
        audio_music_fade_to(0.5f, "bgm/inter.ogg");
        back_push("back/gui.png");
    }

    conf_common_bg_paint(conf_bg_paint);
    common_init(conf_action);

    return transition_slide(conf_gui(), 1, intent);
}

static int conf_leave(struct state *st, struct state *next, int id, int intent)
{
    config_save();

    if (next == conf_back)
    {
        if (!game_server_state())
            back_pop();

        conf_common_bg_paint(NULL);
    }

    return transition_slide(id, 0, intent);
}

/*---------------------------------------------------------------------------*/

static int null_enter(struct state *st, struct state *prev, int intent)
{
    game_client_free_objects();
    back_free_objects();

    hud_free();
    transition_quit();
    gui_free();
    geom_free();
    ball_free();
    shad_free();
    part_free();
    mtrl_free_objects();

    return 0;
}

static int null_leave(struct state *st, struct state *next, int id, int intent)
{
    mtrl_load_objects();
    part_init();
    shad_init();
    ball_init();
    geom_init();
    gui_init();
    transition_init();
    hud_init();

    back_load_objects();
    game_client_load_objects();

    return 0;
}

/*---------------------------------------------------------------------------*/

struct state st_conf = {
    conf_enter,
    conf_leave,
    conf_common_paint,
    common_timer,
    common_point,
    common_stick,
    NULL,
    common_click,
    common_keybd,
    common_buttn
};

struct state st_null = {
    null_enter,
    null_leave,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL
};

/*---------------------------------------------------------------------------*/

enum
{
    GAMEPLAY_CAMERA_DEFAULT = GUI_LAST,
    GAMEPLAY_CAMERA_1_4,
    GAMEPLAY_CAMERA_1_6,
    GAMEPLAY_LOCK_GOALS
};

static struct state *gameplay_back;

static int gameplay_action(int tok, int val)
{
    int r = 1;

    audio_play(AUD_MENU, 1.0f);

    switch (tok)
    {
    case GUI_BACK:
        exit_state(gameplay_back);
        gameplay_back = NULL;
        break;

    case GAMEPLAY_CAMERA_DEFAULT:
        cam_preset_set(CAM_1, CAM_PRESET_DEFAULT);
        goto_state(&st_conf_gameplay);
        break;

    case GAMEPLAY_CAMERA_1_4:
        cam_preset_set(CAM_1, CAM_PRESET_1_4);
        goto_state(&st_conf_gameplay);
        break;

    case GAMEPLAY_CAMERA_1_6:
        cam_preset_set(CAM_1, CAM_PRESET_1_6);
        goto_state(&st_conf_gameplay);
        break;

    case GAMEPLAY_LOCK_GOALS:
        config_set_d(CONFIG_LOCK_GOALS, val);
        goto_state(&st_conf_gameplay);
        break;
    }

    return r;
}

static int gameplay_gui(void)
{
    int id, jd, kd, ld;
    int curr = cam_preset_get(CAM_1);

    if ((id = gui_vstack(0)))
    {
        conf_header(id, _("Gameplay"), GUI_BACK);

        conf_toggle(id, _("Completed Levels"),
                    GAMEPLAY_LOCK_GOALS, config_get_d(CONFIG_LOCK_GOALS),
                    _("Locked"), 1, _("Unlocked"), 0);

        gui_space(id);

        if ((jd = gui_harray(id)) && (kd = gui_vstack(jd)) && (ld = gui_vstack(jd)))
        {
            int btn0 = gui_state(kd, _("Default"),     GUI_SML, GAMEPLAY_CAMERA_DEFAULT, 0);
            int btn1 = gui_state(kd, _("1.4 Classic"), GUI_SML, GAMEPLAY_CAMERA_1_4,     0);
            int btn2 = gui_state(kd, _("1.6 Classic"), GUI_SML, GAMEPLAY_CAMERA_1_6,     0);

            gui_set_hilite(btn0, (curr == CAM_PRESET_DEFAULT));
            gui_set_hilite(btn1, (curr == CAM_PRESET_1_4));
            gui_set_hilite(btn2, (curr == CAM_PRESET_1_6));

            gui_label(ld, _("Camera Preset"), GUI_SML, 0, 0);
            gui_filler(ld);
        }

        gui_layout(id, 0, 0);
    }

    return id;
}

static int gameplay_enter(struct state *st, struct state *prev, int intent)
{
    if (!gameplay_back)
        gameplay_back = prev;

    conf_common_init(gameplay_action);
    return transition_slide(gameplay_gui(), 1, intent);
}

struct state st_conf_gameplay = {
    gameplay_enter,
    conf_common_leave,
    conf_common_paint,
    common_timer,
    common_point,
    common_stick,
    NULL,
    common_click,
    common_keybd,
    common_buttn
};

/*---------------------------------------------------------------------------*/

static int mouse_id[11];

/*
 * This maps mouse_sense 300 (default) to the 7th of an 11 button
 * series. Effectively there are more options for a lower-than-default
 * sensitivity than for a higher one.
 */

#define MOUSE_RANGE_MIN  100
#define MOUSE_RANGE_INC  50
#define MOUSE_RANGE_MAX (MOUSE_RANGE_MIN + (MOUSE_RANGE_INC * 10))

/*
 * Map mouse_sense values to [0, 10]. A higher mouse_sense value means
 * lower sensitivity, thus counter-intuitively, 0 maps to the higher
 * value.
 */

#define MOUSE_RANGE_MAP(m) \
    CLAMP(0, (MOUSE_RANGE_MAX - m) / MOUSE_RANGE_INC, 10)

#define MOUSE_RANGE_UNMAP(i) \
    (MOUSE_RANGE_MAX - (i * MOUSE_RANGE_INC))

enum
{
    CONTROLS_MOUSE_SENSE = GUI_LAST,
    CONTROLS_JOYSTICK,
    CONTROLS_TOUCH
};

static struct state *controls_back;

static int controls_action(int tok, int val)
{
    int mouse = MOUSE_RANGE_MAP(config_get_d(CONFIG_MOUSE_SENSE));
    int r = 1;

    audio_play(AUD_MENU, 1.0f);

    switch (tok)
    {
    case GUI_BACK:
        exit_state(controls_back);
        controls_back = NULL;
        break;

    case CONTROLS_MOUSE_SENSE:
        config_set_d(CONFIG_MOUSE_SENSE, MOUSE_RANGE_UNMAP(val));

        gui_toggle(mouse_id[val]);
        gui_toggle(mouse_id[mouse]);
        break;

    case CONTROLS_JOYSTICK:
        goto_state(&st_joystick);
        break;

    case CONTROLS_TOUCH:
        goto_state(&st_conf_touch);
        break;
    }

    return r;
}

static int controls_gui(void)
{
    int id;
    int mouse = MOUSE_RANGE_MAP(config_get_d(CONFIG_MOUSE_SENSE));

    if ((id = gui_vstack(0)))
    {
        conf_header(id, _("Controls"), GUI_BACK);

        conf_slider(id, _("Mouse Sensitivity"), CONTROLS_MOUSE_SENSE, mouse,
                    mouse_id, ARRAYSIZE(mouse_id));

        gui_space(id);

        conf_state(id, _("Gamepad"), _("Configure"), CONTROLS_JOYSTICK);

        gui_space(id);

        conf_state(id, _("Touch"), _("Configure"), CONTROLS_TOUCH);

        gui_layout(id, 0, 0);
    }

    return id;
}

static int controls_enter(struct state *st, struct state *prev, int intent)
{
    if (!controls_back)
        controls_back = prev;

    conf_common_init(controls_action);
    return transition_slide(controls_gui(), 1, intent);
}

struct state st_conf_controls = {
    controls_enter,
    conf_common_leave,
    conf_common_paint,
    common_timer,
    common_point,
    common_stick,
    NULL,
    common_click,
    common_keybd,
    common_buttn
};

/*---------------------------------------------------------------------------*/

enum
{
    TOUCH_MODE = GUI_LAST,
    TOUCH_ROTATE_INVERT
};

static struct state *touch_back;

static int touch_action(int tok, int val)
{
    int r = 1;

    audio_play(AUD_MENU, 1.0f);

    switch (tok)
    {
    case GUI_BACK:
        exit_state(touch_back);
        touch_back = NULL;
        break;

    case TOUCH_MODE:
        config_set_d(CONFIG_TOUCH_MODE, val);
        goto_state(&st_conf_touch);
        break;

    case TOUCH_ROTATE_INVERT:
        config_set_d(CONFIG_TOUCH_ROTATE_INVERT, val);
        goto_state(&st_conf_touch);
        break;
    }

    return r;
}

static int touch_gui(void)
{
    int id, jd, kd, ld;
    int curr = config_get_d(CONFIG_TOUCH_MODE);

    if ((id = gui_vstack(0)))
    {
        conf_header(id, _("Touch"), GUI_BACK);

        if ((jd = gui_harray(id)) && (kd = gui_vstack(jd)) && (ld = gui_vstack(jd)))
        {
            int btn0 = gui_state(kd, _("Left Tilt"),  GUI_SML, TOUCH_MODE, TOUCH_MODE_LR);
            int btn1 = gui_state(kd, _("Right Tilt"), GUI_SML, TOUCH_MODE, TOUCH_MODE_RL);
            int btn2 = gui_state(kd, _("Dynamic"),    GUI_SML, TOUCH_MODE, TOUCH_MODE_DYNAMIC);

            gui_set_hilite(btn0, (curr == TOUCH_MODE_LR));
            gui_set_hilite(btn1, (curr == TOUCH_MODE_RL));
            gui_set_hilite(btn2, (curr == TOUCH_MODE_DYNAMIC));

            gui_label(ld, _("Mode"), GUI_SML, 0, 0);
            gui_filler(ld);
        }

        gui_space(id);

        conf_toggle(id, _("Invert Rotation"),
                    TOUCH_ROTATE_INVERT,
                    config_get_d(CONFIG_TOUCH_ROTATE_INVERT),
                    _("On"), 1, _("Off"), 0);

        gui_layout(id, 0, 0);
    }

    return id;
}

static int touch_enter(struct state *st, struct state *prev, int intent)
{
    if (!touch_back)
        touch_back = prev;

    conf_common_init(touch_action);
    return transition_slide(touch_gui(), 1, intent);
}

struct state st_conf_touch = {
    touch_enter,
    conf_common_leave,
    conf_common_paint,
    common_timer,
    common_point,
    common_stick,
    NULL,
    common_click,
    common_keybd,
    common_buttn
};
