/*
 * Copyright (C) 2003 Robert Kooima
 *
 * NEVERBALL is  free software; you can redistribute  it and/or modify
 * it under the  terms of the GNU General  Public License as published
 * by the Free  Software Foundation; either version 2  of the License,
 * or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT  ANY  WARRANTY;  without   even  the  implied  warranty  of
 * MERCHANTABILITY or  FITNESS FOR A PARTICULAR PURPOSE.   See the GNU
 * General Public License for more details.
 */

#include <string.h>

#include "gui.h"
#include "transition.h"
#include "set.h"
#include "progress.h"
#include "audio.h"
#include "config.h"
#include "video.h"
#include "demo.h"
#include "lang.h"
#include "key.h"

#include "game_server.h"
#include "game_client.h"
#include "game_common.h"

#include "st_level.h"
#include "st_play.h"
#include "st_start.h"
#include "st_over.h"
#include "st_done.h"
#include "st_pause.h"
#include "st_shared.h"

/*---------------------------------------------------------------------------*/

static int check_nodemo = 1;

enum
{
    LEVEL_START = GUI_LAST,
};

static int level_action(int token, int value)
{
    switch (token)
    {
        case LEVEL_START:
            return goto_state(&st_play_ready);

        case GUI_BACK:
            return goto_abandon();
    }

    return 1;
}

static int level_gui(void)
{
    int id, jd, kd;
    STRBUF title = level_title(curr_level());
    const char *desc = level_desc(curr_level());
    const char *t = CSTR(title);

    if ((id = gui_vstack(0)))
    {
        if ((jd = gui_hstack(id)))
        {
            gui_filler(jd);

            if ((kd = gui_vstack(jd)))
            {
                const char *ln = level_name (curr_level());
                int b          = level_bonus(curr_level());
                const char *hp = (ln && *ln >= '0' && *ln <= '9') ? "#" : "";

                char setattr[MAXSTR], lvlattr[MAXSTR];

                if (*t)
                {
                    SAFECPY(lvlattr, t);

                    if (curr_mode() == MODE_CHALLENGE)
                        sprintf(setattr, "%s %s%s: %s", set_name(curr_set()),
                                hp, ln, mode_to_str(MODE_CHALLENGE, 1));
                    else if (curr_mode() == MODE_STANDALONE)
                        sprintf(setattr, _("Standalone level"));
                    else
                        sprintf(setattr, "%s %s%s", set_name(curr_set()),
                                hp, ln);
                }
                else
                {
                    if (b)
                        sprintf(lvlattr, _("Bonus Level %s"), ln);
                    else
                        sprintf(lvlattr, _("Level %s"), ln);

                    if (curr_mode() == MODE_CHALLENGE)
                        sprintf(setattr, "%s: %s", set_name(curr_set()),
                                mode_to_str(MODE_CHALLENGE, 1));
                    else if (curr_mode() == MODE_STANDALONE)
                        sprintf(setattr, _("Standalone level"));
                    else
                        sprintf(setattr, "%s", set_name(curr_set()));
                }

                int font_size = (!*t && b) ? GUI_MED : GUI_LRG;
                const int max_w = video.device_w;

                if (gui_measure(lvlattr, font_size).w > max_w)
                {
                    if (font_size == GUI_LRG && gui_measure(lvlattr, GUI_MED).w <= max_w)
                        font_size = GUI_MED;
                    else
                        font_size = GUI_SML;
                }

                gui_label(kd, lvlattr,
                        font_size,
                        b ? gui_wht : 0,
                        b ? gui_grn : 0);

                gui_label(kd, setattr, GUI_SML, gui_wht, gui_wht);

                gui_set_rect(kd, GUI_ALL);
            }
            gui_filler(jd);
        }
        gui_space(id);

        if (*desc)
        {
            gui_multi(id, desc, GUI_SML, gui_wht, gui_wht);
            gui_space(id);
        }

        if ((jd = gui_hstack(id)))
        {
            gui_start_icon(jd, GUI_TRIANGLE_RIGHT, gui_grn, _("Start"), GUI_SML, LEVEL_START, 0);
            gui_filler(jd);
            gui_back_button(jd);
        }

        gui_layout(id, 0, 0);
    }

    return id;
}

static int level_enter(struct state *st, struct state *prev, int intent)
{
    video_clr_grab();
    game_client_fly(1.0f);

    if (check_nodemo && !demo_fp)
    {
        goto_state(&st_nodemo);
        return 0;
    }
    else check_nodemo = 1;

    return transition_slide(level_gui(), 1, intent);
}

static void level_timer(int id, float dt)
{
    gui_timer(id, dt);
    game_step_fade(dt);
}

static int level_keybd(int c, int d)
{
    if (d)
    {
        if (c == KEY_EXIT)
            return goto_abandon();
        if (c == KEY_POSE)
            return goto_state(&st_poser);
    }
    return 1;
}

static int level_buttn(int b, int d)
{
    if (d)
    {
        if (config_tst_d(CONFIG_JOYSTICK_BUTTON_A, b))
        {
            int active = gui_active();

            if (active)
                return level_action(gui_token(active), gui_value(active));
            else
                return level_action(LEVEL_START, 0);
        }
        if (config_tst_d(CONFIG_JOYSTICK_BUTTON_START, b))
            return level_action(LEVEL_START, 0);
        if (config_tst_d(CONFIG_JOYSTICK_BUTTON_B, b))
            return level_action(GUI_BACK, 0);
    }
    return 1;
}

static int level_click(int b, int d)
{
    if (gui_click(b, d))
        return level_buttn(config_get_d(CONFIG_JOYSTICK_BUTTON_A), 1);

    return (b == SDL_BUTTON_LEFT && d == 0) ? goto_state(&st_play_ready) : 1;
}

/*---------------------------------------------------------------------------*/

static void poser_paint(int id, float t)
{
    game_client_draw(POSE_LEVEL, t);
}

static int poser_keybd(int c, int d)
{
    if (d)
    {
        if (c == KEY_EXIT || c == KEY_POSE)
            return goto_state(&st_level);
    }
    return 1;
}

static int poser_buttn(int c, int d)
{
    if (d && config_tst_d(CONFIG_JOYSTICK_BUTTON_B, c))
        return goto_state(&st_level);

    return 1;
}

/*---------------------------------------------------------------------------*/

static int nodemo_gui(void)
{
    int id;

    if ((id = gui_vstack(0)))
    {
        gui_label(id, _("Warning!"), GUI_MED, 0, 0);
        gui_space(id);
        gui_multi(id, _("A replay file could not be opened for writing.\n"
                        "This game will not be recorded.\n"),
                  GUI_SML, gui_wht, gui_wht);

        gui_layout(id, 0, 0);
    }

    return id;
}

static int nodemo_enter(struct state *st, struct state *prev, int intent)
{
    check_nodemo = 0;

    return transition_slide(nodemo_gui(), 1, intent);
}

static void nodemo_timer(int id, float dt)
{
    game_step_fade(dt);
    gui_timer(id, dt);
}

static int nodemo_keybd(int c, int d)
{
    if (d)
    {
        if (c == KEY_EXIT)
            return goto_state(&st_level);
    }
    return 1;
}

static int nodemo_buttn(int b, int d)
{
    if (d)
    {
        if (config_tst_d(CONFIG_JOYSTICK_BUTTON_A, b))
            return goto_state(&st_level);
        if (config_tst_d(CONFIG_JOYSTICK_BUTTON_B, b))
            return goto_state(&st_level);
    }
    return 1;
}


/*---------------------------------------------------------------------------*/

int goto_exit(void)
{
    struct state *curr = curr_state();
    struct state *dst;

    game_server_free(NULL);

    if (progress_done())
        dst = &st_done;
    else if (curr_mode() == MODE_CHALLENGE)
        dst = &st_over;
    else if (curr_mode() == MODE_STANDALONE)
        dst = NULL;
    else
        dst = &st_start;

    if (dst)
    {
        /* Visit the auxilliary screen or exit to level selection. */

        if (dst != curr && dst != &st_start)
            goto_state(dst);
        else
            exit_state(&st_start);
    }
    else
    {
        /* Quit the game. */

        SDL_Event e = { SDL_QUIT };
        SDL_PushEvent(&e);
    }

    return 1;
}

int goto_abandon(void)
{
    if (curr_mode() == MODE_CHALLENGE)
        return goto_state(&st_abandon);

    progress_stop();
    return goto_exit();
}

/*---------------------------------------------------------------------------*/

static struct state *abandon_back = NULL;

enum
{
    ABANDON_YES = GUI_LAST,
};

static int abandon_action(int tok, int val)
{
    audio_play(AUD_MENU, 1.0f);

    switch (tok)
    {
    case GUI_BACK:
        // Back = no.
        audio_music_fade_in(1.0f);
        return goto_state(abandon_back);

    case ABANDON_YES:
        progress_stat(GAME_NONE);
        progress_stop();
        audio_music_stop();
        return goto_exit();
    }

    return 1;

}

static int abandon_gui(void)
{
    int id, jd;

    if ((id = gui_vstack(0)))
    {
        gui_label(id, _("Give Up?"), GUI_MED, 0, 0);

        gui_space(id);

        gui_multi(id, _("You are playing in challenge mode.\n"
                        "Do you want to abandon this run?"),
                  GUI_SML, gui_wht, gui_wht);

        gui_space(id);

        if ((jd = gui_harray(id)))
        {
            gui_state_icon(jd, GUI_CROSS, gui_red, _("Give Up"), GUI_SML, ABANDON_YES, 0);

            gui_start_icon(jd, GUI_TRIANGLE_RIGHT, gui_grn, _("Never!"), GUI_SML, GUI_BACK, 0);
        }

        gui_layout(id, 0, 0);
    }

    return id;
}

static int abandon_enter(struct state *st, struct state *prev, int intent)
{
    abandon_back = prev;
    audio_music_fade_out(1.0f);
    return transition_slide(abandon_gui(), 1, intent);
}

static int abandon_buttn(int b, int d)
{
    if (d)
    {
        int active = gui_active();

        int token = gui_token(active);
        int value = gui_value(active);

        if (config_tst_d(CONFIG_JOYSTICK_BUTTON_A, b))
            return abandon_action(token, value);
        if (config_tst_d(CONFIG_JOYSTICK_BUTTON_B, b))
            return abandon_action(GUI_BACK, 0);
    }
    return 1;
}

static int abandon_keybd(int c, int d)
{
    if (d)
    {
        if (c == KEY_EXIT)
            return abandon_buttn(config_get_d(CONFIG_JOYSTICK_BUTTON_B), 1);
    }
    return 1;
}

/*---------------------------------------------------------------------------*/

struct state st_level = {
    level_enter,
    shared_leave,
    shared_paint,
    level_timer,
    shared_point,
    shared_stick,
    NULL,
    level_click,
    level_keybd,
    level_buttn
};

struct state st_poser = {
    NULL,
    NULL,
    poser_paint,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    poser_keybd,
    poser_buttn
};

struct state st_nodemo = {
    nodemo_enter,
    shared_leave,
    shared_paint,
    nodemo_timer,
    shared_point,
    shared_stick,
    shared_angle,
    shared_click_basic,
    nodemo_keybd,
    nodemo_buttn
};

struct state st_abandon = {
    abandon_enter,
    shared_leave,
    shared_paint,
    shared_timer,
    shared_point,
    shared_stick,
    shared_angle,
    shared_click,
    abandon_keybd,
    abandon_buttn
};