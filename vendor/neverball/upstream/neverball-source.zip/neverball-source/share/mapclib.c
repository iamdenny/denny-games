/*
 * Copyright (C) 2003 Robert Kooima
 * Copyright (C) 2025 Jānis Rūcis
 *
 * NEVERBALL is  free software; you can redistribute  it and/or modify
 * it under the  terms of the GNU General  Public License as published
 * by the Free  Software Foundation; either version 2  of the License,
 * or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT  ANY  WARRANTY;  without   even  the  implied  warranty  of
 * MERCHANTABILITY or  FITNESS FOR A PARTICULAR PURPOSE.   See the GNU
 * General Public License for more details.
 */

/*---------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <stddef.h> /* offsetof */
#include <string.h>
#include <math.h>
#include <sys/time.h>
#include <assert.h>
#include <setjmp.h>

#if ENABLE_RADIANT_CONSOLE
/*
 * Mapc is not an SDL app, we just want the SDL_net symbols.
 */
#define WITHOUT_SDL 1
#include <SDL_net.h>
#endif

#include "mapclib.h"

#include "solid_base.h"

#include "vec3.h"
#include "base_image.h"
#include "base_config.h"
#include "fs.h"
#include "common.h"
#include "strbuf/base_name.h"
#include "strbuf/dir_name.h"
#include "strbuf/joinstr.h"
#include "strbuf/substr.h"

#define MAXSTR 256
#define MAXKEY 16
#define SCALE  64.f
#define SMALL  0.0005f

#define GOAL_HALF_EXTENT 48.f
#define SWCH_HALF_EXTENT 32.f
#define JUMP_HALF_EXTENT 32.f

/* Epsilon used for vertex merging within lumps. */
#define SMALL_VERT 1e-4f
/* Epsilon used for plane intersection checks during vertex clipping. */
#define SMALL_CLIP 1e-7 /* double */
/* Epsilon used for stable lump side testing during BSP construction. */
#define SMALL_NODE 1e-5f

#define MAX_VERT_PLANES 128

/*
 * The overall design  of this map converter is  very stupid, but very
 * simple. It  begins by assuming  that every mtrl, vert,  edge, side,
 * and texc  in the map is  unique.  It then makes  an optimizing pass
 * that discards redundant information.  The result is optimal, though
 * the process is terribly inefficient.
 */

/*---------------------------------------------------------------------------*/

/* Ohhhh... arbitrary! */

#define MAXM    1024
#define MAXV    65536
#define MAXE    131072
#define MAXS    65536
#define MAXT    131072
#define MAXO    262144
#define MAXG    65536
#define MAXL    4096
#define MAXN    2048
#define MAXP    2048
#define MAXB    1024
#define MAXH    2048
#define MAXZ    1024
#define MAXJ    1024
#define MAXX    1024
#define MAXR    2048
#define MAXU    1024
#define MAXW    1024
#define MAXD    1024
#define MAXA    16384
#define MAXI    262144

/*
 * The following is a small  symbol table data structure.  Symbols and
 * their integer  values are collected  in symv and  valv.  References
 * and pointers  to their unsatisfied integer values  are collected in
 * refv and pntv.  The resolve procedure matches references to symbols
 * and fills waiting ints with the proper values.
 */

#define MAXSYM 2048

enum
{
    SYM_NONE = 0,

    SYM_PATH,
    SYM_TARG,

    SYM_MAX
};

struct sym
{
    int  type;
    char name[MAXSTR];
    int  val;
};

struct ref
{
    int  type;
    char name[MAXSTR];
    int *ptr;
};

struct _imagedata
{
    char *s;
    int w, h;
};

enum mapc_jmp
{
    MAPC_SUCCESS = 0,
    MAPC_ERROR,
};

#if ENABLE_RADIANT_CONSOLE
#define MAX_BCAST_MSG 512
#endif

/*
 * Context structure to hold all global state.
 */
struct mapc_context
{
    const char *opt_file;
    const char *opt_data;
    int opt_debug;
    int opt_csv;

    STRBUF src_path;
    STRBUF dst_path;

    STRBUF full_dst_path;

#if ENABLE_RADIANT_CONSOLE
    TCPsocket bcast_socket;
    unsigned char bcast_msg[MAX_BCAST_MSG];
    size_t bcast_msg_len;
#endif

    struct sym syms[MAXSYM];
    struct ref refs[MAXSYM];
    int symc;
    int refc;

    float targ_p[MAXW][3];
    int targ_wi[MAXW];
    int targ_ji[MAXW];
    int targ_n;

    float item_e[MAXH][4];
    int   item_has_e[MAXH];

    float goal_e[MAXZ][4];
    int   goal_has_e[MAXZ];
    int   goal_is_legacy[MAXZ];

    float jump_e[MAXJ][4];
    int   jump_has_e[MAXJ];
    int   jump_is_legacy[MAXJ];

    float swch_e[MAXX][4];
    int   swch_has_e[MAXX];
    int   swch_is_legacy[MAXX];

    float bill_e[MAXR][4];
    int   bill_has_e[MAXR];

    struct _imagedata *imagedata;
    int image_n;
    int image_alloc;

    double plane_d[MAXS];
    double plane_n[MAXS][3];
    float plane_p[MAXS][3];
    float plane_u[MAXS][3];
    float plane_v[MAXS][3];
    int plane_f[MAXS];
    int plane_m[MAXS];

    int vert_planes[MAXV][MAX_VERT_PLANES];
    int vert_plane_count[MAXV];

    int read_dict_entries;

    int mtrl_swaps[MAXM];
    int edge_swaps[MAXE];
    int side_swaps[MAXS];
    int texc_swaps[MAXT];
    int offs_swaps[MAXO];
    int geom_swaps[MAXG];

    struct s_base file;

    jmp_buf jmpbuf;

    double compile_time;
};

/*---------------------------------------------------------------------------*/

#if ENABLE_RADIANT_CONSOLE

/*
 * Message levels from radiant/console.h
 */
#define BCAST_STD 1
#define BCAST_WRN 2
#define BCAST_ERR 3

static void bcast_quit(struct mapc_context *ctx);

static int bcast_error(struct mapc_context *ctx)
{
    fprintf(stderr, "%s\n", SDLNet_GetError());
    bcast_quit(ctx);
    return 0;
}

static void bcast_write_len(struct mapc_context *ctx, size_t len)
{
    unsigned char *p = &ctx->bcast_msg[ctx->bcast_msg_len];

    if (ctx->bcast_msg_len + 4u < sizeof (ctx->bcast_msg))
    {
        p[0] =  len        & 0xff;
        p[1] = (len >> 8)  & 0xff;
        p[2] = (len >> 16) & 0xff;
        p[3] = (len >> 24) & 0xff;

        ctx->bcast_msg_len += 4u;
    }
}

static void bcast_write_str(struct mapc_context *ctx, const char *str)
{
    if (str && *str)
    {
        unsigned char *p = &ctx->bcast_msg[ctx->bcast_msg_len];
        size_t         n = MIN(strlen(str), (sizeof (ctx->bcast_msg) -
                                             ctx->bcast_msg_len - 1));

        memcpy(p, str, n);
        p[n] = 0;

        ctx->bcast_msg_len += n + 1;
    }
}

static void bcast_send_str(struct mapc_context *ctx, const char *str)
{
    size_t len;

    /* Reserve 4 bytes. */

    ctx->bcast_msg_len = 4;

    /* Write the string. */

    bcast_write_str(ctx, str);

    /* Write its length in the reserved 4 bytes. */

    len = ctx->bcast_msg_len;
    ctx->bcast_msg_len = 0;
    bcast_write_len(ctx, len - 4);
    ctx->bcast_msg_len = len;

    /* Send data. */

    if (ctx->bcast_socket &&
        SDLNet_TCP_Send(ctx->bcast_socket,
                        ctx->bcast_msg,
                        ctx->bcast_msg_len) < ctx->bcast_msg_len)
        bcast_error(ctx);
}

static void bcast_send_msg(struct mapc_context *ctx, int lvl, const char *str)
{
    char buf[512];
    int maxstr;

    assert(lvl > 0 && lvl < 10);

    /*
     * These are not real time. Radiant will buffer them and randomly
     * flush the buffer whenever it feels like (usually upon
     * disconnection). It also stops processing after a level 3
     * message.
     */

    maxstr = sizeof (buf) - sizeof ("<message level=\"1\"></message>");
    sprintf(buf, "<message level=\"%1d\">%.*s</message>", lvl, maxstr, str);
    bcast_send_str(ctx, buf);
}

static int bcast_init(struct mapc_context *ctx)
{
    IPaddress addr;

    if (SDLNet_Init() == -1)
        return bcast_error(ctx);
    if (SDLNet_ResolveHost(&addr, "127.0.0.1", 39000) == -1)
        return bcast_error(ctx);
    if (!(ctx->bcast_socket = SDLNet_TCP_Open(&addr)))
        return bcast_error(ctx);

    bcast_send_str(ctx, "<?xml version=\"1.0\"?>"
                   "<q3map_feedback version=\"1\">");
    return 1;
}

static void bcast_quit(struct mapc_context *ctx)
{
    SDLNet_TCP_Close(ctx->bcast_socket);
    ctx->bcast_socket = NULL;
    SDLNet_Quit();
}

#define MESSAGE(ctx, str) do {                       \
        bcast_send_msg(ctx, BCAST_STD, (str));       \
        fprintf(stdout, "%s", str);             \
    } while (0)

#define WARNING(ctx, str) do {                       \
        bcast_send_msg(ctx, BCAST_WRN, (str));       \
        fprintf(stderr, "%s", str);             \
    } while (0)

#define ERROR(ctx, str) do {                         \
        bcast_send_msg(ctx, BCAST_ERR, (str));       \
        fprintf(stderr, "%s", str);             \
    } while (0)

#else /* ENABLE_RADIANT_CONSOLE */

#define MESSAGE(ctx, str) do {                       \
        fprintf(stdout, "%s", str);             \
    } while (0)

#define WARNING(ctx, str) do {                       \
        fprintf(stderr, "%s", str);             \
    } while (0)

#define ERROR(ctx, str) do {                         \
        fprintf(stderr, "%s", str);             \
    } while (0)

#endif /* ENABLE_RADIANT_CONSOLE */

/*---------------------------------------------------------------------------*/

static void init_file(struct s_base *fp);

int mapc_init(struct mapc_context **ctx_ptr)
{
    struct mapc_context *ctx = NULL;

    if (!ctx_ptr)
        return 0;

    ctx = malloc(sizeof(*ctx));

    if (!ctx)
        return 0;

    memset(ctx, 0, sizeof(*ctx));

    ctx->opt_debug = 0;
    ctx->opt_csv = 0;
    ctx->opt_file = NULL;
    ctx->opt_data = NULL;

#if ENABLE_RADIANT_CONSOLE
    ctx->bcast_socket = NULL;
    ctx->bcast_msg_len = 0;
#endif

    ctx->symc = 0;
    ctx->refc = 0;
    ctx->targ_n = 0;
    ctx->imagedata = NULL;
    ctx->image_n = 0;
    ctx->image_alloc = 0;
    ctx->read_dict_entries = 0;

    init_file(&ctx->file);

    *ctx_ptr = ctx;

    return 1;
}

void mapc_quit(struct mapc_context **ctx_ptr)
{
    struct mapc_context *ctx = NULL;
    int i;

    if (!ctx_ptr)
        return;

    ctx = *ctx_ptr;

    if (!ctx)
        return;

    if (ctx->imagedata)
    {
        for (i = 0; i < ctx->image_n; i++)
            free(ctx->imagedata[i].s);

        free(ctx->imagedata);
        ctx->imagedata = NULL;
    }

    ctx->image_n = 0;
    ctx->image_alloc = 0;

#if ENABLE_RADIANT_CONSOLE
    bcast_quit(ctx);
#endif

    free(ctx);
    ctx = NULL;

    *ctx_ptr = NULL;
}

/*---------------------------------------------------------------------------*/

static int overflow(struct mapc_context *ctx, const char s[64u - sizeof (" overflow\n")])
{
    char buf[64];
    sprintf(buf, "%s overflow\n", s);
    ERROR(ctx, buf);
    longjmp(ctx->jmpbuf, MAPC_ERROR);
    return 0;
}

static int incm(struct mapc_context *ctx)
{
    struct s_base *fp = &ctx->file;
    return (fp->mc < MAXM) ? fp->mc++ : overflow(ctx, "mtrl");
}

static int incv(struct mapc_context *ctx)
{
    struct s_base *fp = &ctx->file;
    return (fp->vc < MAXV) ? fp->vc++ : overflow(ctx, "vert");
}

static int ince(struct mapc_context *ctx)
{
    struct s_base *fp = &ctx->file;
    return (fp->ec < MAXE) ? fp->ec++ : overflow(ctx, "edge");
}

static int incs(struct mapc_context *ctx)
{
    struct s_base *fp = &ctx->file;
    return (fp->sc < MAXS) ? fp->sc++ : overflow(ctx, "side");
}

static int inct(struct mapc_context *ctx)
{
    struct s_base *fp = &ctx->file;
    return (fp->tc < MAXT) ? fp->tc++ : overflow(ctx, "texc");
}

static int inco(struct mapc_context *ctx)
{
    struct s_base *fp = &ctx->file;
    return (fp->oc < MAXO) ? fp->oc++ : overflow(ctx, "offs");
}

static int incg(struct mapc_context *ctx)
{
    struct s_base *fp = &ctx->file;
    return (fp->gc < MAXG) ? fp->gc++ : overflow(ctx, "geom");
}

static int incl(struct mapc_context *ctx)
{
    struct s_base *fp = &ctx->file;
    return (fp->lc < MAXL) ? fp->lc++ : overflow(ctx, "lump");
}

static int incn(struct mapc_context *ctx)
{
    struct s_base *fp = &ctx->file;
    return (fp->nc < MAXN) ? fp->nc++ : overflow(ctx, "node");
}

static int incp(struct mapc_context *ctx)
{
    struct s_base *fp = &ctx->file;
    return (fp->pc < MAXP) ? fp->pc++ : overflow(ctx, "path");
}

static int incb(struct mapc_context *ctx)
{
    struct s_base *fp = &ctx->file;
    return (fp->bc < MAXB) ? fp->bc++ : overflow(ctx, "body");
}

static int inch(struct mapc_context *ctx)
{
    struct s_base *fp = &ctx->file;
    return (fp->hc < MAXH) ? fp->hc++ : overflow(ctx, "item");
}

static int incz(struct mapc_context *ctx)
{
    struct s_base *fp = &ctx->file;
    return (fp->zc < MAXZ) ? fp->zc++ : overflow(ctx, "goal");
}

static int incj(struct mapc_context *ctx)
{
    struct s_base *fp = &ctx->file;
    return (fp->jc < MAXJ) ? fp->jc++ : overflow(ctx, "jump");
}

static int incx(struct mapc_context *ctx)
{
    struct s_base *fp = &ctx->file;
    return (fp->xc < MAXX) ? fp->xc++ : overflow(ctx, "swch");
}

static int incr(struct mapc_context *ctx)
{
    struct s_base *fp = &ctx->file;
    return (fp->rc < MAXR) ? fp->rc++ : overflow(ctx, "bill");
}

static int incu(struct mapc_context *ctx)
{
    struct s_base *fp = &ctx->file;
    return (fp->uc < MAXU) ? fp->uc++ : overflow(ctx, "ball");
}

static int incw(struct mapc_context *ctx)
{
    struct s_base *fp = &ctx->file;
    return (fp->wc < MAXW) ? fp->wc++ : overflow(ctx, "view");
}

static int incd(struct mapc_context *ctx)
{
    struct s_base *fp = &ctx->file;
    return (fp->dc < MAXD) ? fp->dc++ : overflow(ctx, "dict");
}

static int inci(struct mapc_context *ctx)
{
    struct s_base *fp = &ctx->file;
    return (fp->ic < MAXI) ? fp->ic++ : overflow(ctx, "indx");
}

static void init_file(struct s_base *fp)
{
    fp->mc = 0;
    fp->vc = 0;
    fp->ec = 0;
    fp->sc = 0;
    fp->tc = 0;
    fp->oc = 0;
    fp->gc = 0;
    fp->lc = 0;
    fp->nc = 0;
    fp->pc = 0;
    fp->bc = 0;
    fp->hc = 0;
    fp->zc = 0;
    fp->jc = 0;
    fp->xc = 0;
    fp->rc = 0;
    fp->uc = 0;
    fp->wc = 0;
    fp->dc = 0;
    fp->ac = 0;
    fp->ic = 0;

    fp->mv = (struct b_mtrl *) calloc(MAXM, sizeof (*fp->mv));
    fp->vv = (struct b_vert *) calloc(MAXV, sizeof (*fp->vv));
    fp->ev = (struct b_edge *) calloc(MAXE, sizeof (*fp->ev));
    fp->sv = (struct b_side *) calloc(MAXS, sizeof (*fp->sv));
    fp->tv = (struct b_texc *) calloc(MAXT, sizeof (*fp->tv));
    fp->ov = (struct b_offs *) calloc(MAXO, sizeof (*fp->ov));
    fp->gv = (struct b_geom *) calloc(MAXG, sizeof (*fp->gv));
    fp->lv = (struct b_lump *) calloc(MAXL, sizeof (*fp->lv));
    fp->nv = (struct b_node *) calloc(MAXN, sizeof (*fp->nv));
    fp->pv = (struct b_path *) calloc(MAXP, sizeof (*fp->pv));
    fp->bv = (struct b_body *) calloc(MAXB, sizeof (*fp->bv));
    fp->hv = (struct b_item *) calloc(MAXH, sizeof (*fp->hv));
    fp->zv = (struct b_goal *) calloc(MAXZ, sizeof (*fp->zv));
    fp->jv = (struct b_jump *) calloc(MAXJ, sizeof (*fp->jv));
    fp->xv = (struct b_swch *) calloc(MAXX, sizeof (*fp->xv));
    fp->rv = (struct b_bill *) calloc(MAXR, sizeof (*fp->rv));
    fp->uv = (struct b_ball *) calloc(MAXU, sizeof (*fp->uv));
    fp->wv = (struct b_view *) calloc(MAXW, sizeof (*fp->wv));
    fp->dv = (struct b_dict *) calloc(MAXD, sizeof (*fp->dv));
    fp->av = (char *)          calloc(MAXA, sizeof (*fp->av));
    fp->iv = (int *)           calloc(MAXI, sizeof (*fp->iv));
}

/*---------------------------------------------------------------------------*/

static void make_sym(struct mapc_context *ctx, int type, const char *name, int val)
{
    if (ctx->symc < MAXSYM - 1)
    {
        struct sym *sym = &ctx->syms[ctx->symc];

        sym->type = type;
        strncpy(sym->name, name, MAXSTR - 1);
        sym->val = val;

        ctx->symc++;
    }
}

static void make_ref(struct mapc_context *ctx, int type, const char *name, int *ptr)
{
    if (ctx->refc < MAXSYM - 1)
    {
        struct ref *ref = &ctx->refs[ctx->refc];

        ref->type = type;
        strncpy(ref->name, name, MAXSTR - 1);
        ref->ptr = ptr;

        ctx->refc++;
    }
}

static void resolve(struct mapc_context *ctx)
{
    int i, j;

    for (i = 0; i < ctx->refc; i++)
        for (j = 0; j < ctx->symc; j++)
        {
            struct ref *ref = &ctx->refs[i];
            struct sym *sym = &ctx->syms[j];

            if (ref->type == sym->type && strcmp(ref->name, sym->name) == 0)
            {
                *(ref->ptr) = sym->val;
                break;
            }
        }
}

/*---------------------------------------------------------------------------*/

/*
 * The following globals are used to cache target_positions.  They are
 * targeted by various entities and must be resolved in a second pass.
 */

static void targets(struct mapc_context *ctx)
{
    struct s_base *fp = &ctx->file;
    int i;

    for (i = 0; i < fp->wc; i++)
        v_cpy(fp->wv[i].q, ctx->targ_p[ctx->targ_wi[i]]);

    for (i = 0; i < fp->jc; i++)
        v_cpy(fp->jv[i].q, ctx->targ_p[ctx->targ_ji[i]]);
}

/*---------------------------------------------------------------------------*/

/*
 * The following code caches  image sizes.  Textures are referenced by
 * name,  but  their  sizes   are  necessary  when  computing  texture
 * coordinates.  This code  allows each file to be  accessed only once
 * regardless of the number of surfaces referring to it.
 */

#define IMAGE_REALLOC 32

static int size_load(const char *file, int *w, int *h)
{
    void *p;

    if ((p = image_load(file, w, h, NULL)))
    {
        free(p);
        return 1;
    }
    return 0;
}

static void size_image(struct mapc_context *ctx, const char *name, int *w, int *h)
{
    char path[MAXSTR];
    int i;

    if (ctx->imagedata)
        for (i = 0; i < ctx->image_n; i++)
            if (strncmp(ctx->imagedata[i].s, name, MAXSTR) == 0)
            {
                *w = ctx->imagedata[i].w;
                *h = ctx->imagedata[i].h;

                return;
            }

    *w = 0;
    *h = 0;

    for (i = 0; i < ARRAYSIZE(tex_paths); i++)
    {
        CONCAT_PATH(path, &tex_paths[i], name);

        if (size_load(path, w, h))
            break;
    }

    if (*w > 0 && *h > 0)
    {
        if (ctx->image_n + 1 >= ctx->image_alloc)
        {
            struct _imagedata *tmp =
                (struct _imagedata *) malloc(sizeof(struct _imagedata) * (ctx->image_alloc + IMAGE_REALLOC));
            if (!tmp)
            {
                printf("malloc error\n");
                exit(1);
            }
            if (ctx->imagedata)
            {
                (void) memcpy(tmp, ctx->imagedata, sizeof(struct _imagedata) * ctx->image_alloc);
                free(ctx->imagedata);
            }
            ctx->imagedata = tmp;
            ctx->image_alloc += IMAGE_REALLOC;
        }

        ctx->imagedata[ctx->image_n].s = (char *) calloc(strlen(name) + 1, 1);
        ctx->imagedata[ctx->image_n].w = *w;
        ctx->imagedata[ctx->image_n].h = *h;
        strcpy(ctx->imagedata[ctx->image_n].s, name);

        ctx->image_n++;
    }
}

/*---------------------------------------------------------------------------*/

/* Read the given material file, adding a new material to the solid.  */

static int read_mtrl(struct mapc_context *ctx, const char *name)
{
    static char buf [MAXSTR];
    struct s_base *fp = &ctx->file;

    struct b_mtrl *mp;
    int mi;

    for (mi = 0; mi < fp->mc; mi++)
        if (strncmp(name, fp->mv[mi].f, MAXSTR) == 0)
            return mi;

    mp = fp->mv + incm(ctx);

    if (!mtrl_read(mp, name))
    {
        SAFECPY(buf, ctx->opt_file);
        SAFECAT(buf, ": unknown material \"");
        SAFECAT(buf, name);
        SAFECAT(buf, "\"\n");
        WARNING(ctx, buf);
    }

    return mi;
}

#undef scan_vec4

/*---------------------------------------------------------------------------*/

/*
 * All bodies with an associated  path are assumed to be positioned at
 * the  beginning of that  path.  These  bodies must  be moved  to the
 * origin  in order  for their  path transforms  to  behave correctly.
 * This is  how we get away  with defining func_trains  with no origin
 * specification.
 */

static void move_side(struct b_side *sp, const float p[3])
{
    sp->d -= v_dot(sp->n, p);
}

static void move_vert(struct b_vert *vp, const float p[3])
{
    v_sub(vp->p, vp->p, p);
}

static void move_lump(struct mapc_context *ctx,
                      struct b_lump *lp, const float p[3])
{
    struct s_base *fp = &ctx->file;
    int i;

    for (i = 0; i < lp->sc; i++)
        move_side(fp->sv + fp->iv[lp->s0 + i], p);
    for (i = 0; i < lp->vc; i++)
        move_vert(fp->vv + fp->iv[lp->v0 + i], p);
}

static void move_body(struct mapc_context *ctx,
                      struct b_body *bp)
{
    struct s_base *fp = &ctx->file;
    int i, *b;

    /* Move the lumps. */

    for (i = 0; i < bp->lc; i++)
        move_lump(ctx, fp->lv + bp->l0 + i, fp->pv[bp->p0].p);

    /* Create an array to mark any verts referenced by moved geoms. */

    if (bp->gc > 0 && (b = (int *) calloc(fp->vc, sizeof (int))))
    {
        /* Mark the verts. */

        for (i = 0; i < bp->gc; i++)
        {
            const struct b_geom *gp = fp->gv + fp->iv[bp->g0 + i];

            b[fp->ov[gp->oi].vi] = 1;
            b[fp->ov[gp->oj].vi] = 1;
            b[fp->ov[gp->ok].vi] = 1;
        }

        /* Apply the motion to the marked vertices. */

        for (i = 0; i < fp->vc; ++i)
            if (b[i])
                move_vert(fp->vv + i, fp->pv[bp->p0].p);

        free(b);
    }
}

static void move_item(struct mapc_context *ctx,
                      struct b_item *hp)
{
    struct s_base *fp = &ctx->file;
    v_sub(hp->p, hp->p, fp->pv[hp->p0].p);
}

static void move_goal(struct mapc_context *ctx,
                      struct b_goal *zp)
{
    struct s_base *fp = &ctx->file;
    v_sub(zp->p, zp->p, fp->pv[zp->p0].p);
}

static void move_jump(struct mapc_context *ctx,
                      struct b_jump *jp)
{
    struct s_base *fp = &ctx->file;
    v_sub(jp->p, jp->p, fp->pv[jp->p0].p);
}

static void move_swch(struct mapc_context *ctx,
                      struct b_swch *xp)
{
    struct s_base *fp = &ctx->file;
    v_sub(xp->p, xp->p, fp->pv[xp->p0].p);
}

static void move_bill(struct mapc_context *ctx,
                      struct b_bill *rp)
{
    struct s_base *fp = &ctx->file;
    v_sub(rp->p, rp->p, fp->pv[rp->p0].p);
}

static void move_file(struct mapc_context *ctx)
{
    struct s_base *fp = &ctx->file;
    int i;

    for (i = 0; i < fp->bc; i++)
        if (fp->bv[i].p0 >= 0)
            move_body(ctx, fp->bv + i);

    for (i = 0; i < fp->hc; i++)
        if (fp->hv[i].p0 >= 0)
            move_item(ctx, fp->hv + i);

    for (i = 0; i < fp->zc; i++)
        if (fp->zv[i].p0 >= 0)
            move_goal(ctx, fp->zv + i);

    for (i = 0; i < fp->jc; i++)
        if (fp->jv[i].p0 >= 0)
            move_jump(ctx, fp->jv + i);

    for (i = 0; i < fp->xc; i++)
        if (fp->xv[i].p0 >= 0)
            move_swch(ctx, fp->xv + i);

    for (i = 0; i < fp->rc; i++)
        if (fp->rv[i].p0 >= 0)
            move_bill(ctx, fp->rv + i);

    /* Paths must be moved last and all at once. */

    if (fp->pc > 0)
    {
        float (*posv)[3] = calloc(fp->pc, sizeof (float[3]));

        if (posv)
        {
            for (i = 0; i < fp->pc; i++)
            {
                struct b_path *pp = fp->pv + i;

                if (pp->p0 >= 0)
                {
                    struct b_path *pq = fp->pv + pp->p0;

                    v_sub(posv[i], pp->p, pq->p);
                }
            }

            for (i = 0; i < fp->pc; i++)
            {
                struct b_path *pp = fp->pv + i;

                if (pp->p0 >= 0)
                    v_cpy(fp->pv[i].p, posv[i]);
            }

            free(posv);
            posv = NULL;
        }
    }
}

/*---------------------------------------------------------------------------*/

/*
 * This is a basic OBJ loader.  It is by no means fully compliant with
 * the  OBJ  specification, but  it  works  well  with the  output  of
 * Wings3D.  All faces must be triangles and all vertices must include
 * normals and  texture coordinates.  Material  names are taken  to be
 * references to Neverball materials, rather than MTL definitions.
 */

static void read_vt(struct mapc_context *ctx, const char *line)
{
    struct s_base *fp = &ctx->file;
    struct b_texc *tp = fp->tv + inct(ctx);

    sscanf(line, "%f %f", tp->u, tp->u + 1);
}

static void read_vn(struct mapc_context *ctx, const char *line)
{
    struct s_base *fp = &ctx->file;
    struct b_side *sp = fp->sv + incs(ctx);

    sscanf(line, "%f %f %f", sp->n, sp->n + 1, sp->n + 2);
}

static void read_v(struct mapc_context *ctx, const char *line)
{
    struct s_base *fp = &ctx->file;
    struct b_vert *vp = fp->vv + incv(ctx);

    sscanf(line, "%f %f %f", vp->p, vp->p + 1, vp->p + 2);
}

static void parse_triplet(const char *token, int *vi, int *ti, int *si)
{
    *vi = 0;
    *ti = 0;
    *si = 0;

    if (sscanf(token, "%d/%d/%d", vi, ti, si) == 3) return;
    if (sscanf(token, "%d//%d", vi, si) == 2)       return;
    if (sscanf(token, "%d/%d", vi, ti) == 2)        return;
    if (sscanf(token, "%d", vi) == 1)               return;
}

static void read_f(struct mapc_context *ctx, const char *line,
                   int v0, int t0, int s0, int mi)
{
    struct s_base *fp = &ctx->file;
    struct b_geom *gp = fp->gv + incg(ctx);

    struct b_offs *op = fp->ov + (gp->oi = inco(ctx));
    struct b_offs *oq = fp->ov + (gp->oj = inco(ctx));
    struct b_offs *or = fp->ov + (gp->ok = inco(ctx));

    char tok1[64] = "";
    char tok2[64] = "";
    char tok3[64] = "";

    int vi1 = 0, ti1 = 0, si1 = 0;
    int vi2 = 0, ti2 = 0, si2 = 0;
    int vi3 = 0, ti3 = 0, si3 = 0;

    if (sscanf(line, "%63s %63s %63s", tok1, tok2, tok3) == 3)
    {
        parse_triplet(tok1, &vi1, &ti1, &si1);
        parse_triplet(tok2, &vi2, &ti2, &si2);
        parse_triplet(tok3, &vi3, &ti3, &si3);
    }

    op->vi = v0 + vi1 - 1;
    oq->vi = v0 + vi2 - 1;
    or->vi = v0 + vi3 - 1;

    op->ti = ti1 > 0 ? (t0 + ti1 - 1) : (t0 < fp->tc ? t0 : 0);
    oq->ti = ti2 > 0 ? (t0 + ti2 - 1) : (t0 < fp->tc ? t0 : 0);
    or->ti = ti3 > 0 ? (t0 + ti3 - 1) : (t0 < fp->tc ? t0 : 0);

    op->si = si1 > 0 ? (s0 + si1 - 1) : (s0 < fp->sc ? s0 : 0);
    oq->si = si2 > 0 ? (s0 + si2 - 1) : (s0 < fp->sc ? s0 : 0);
    or->si = si3 > 0 ? (s0 + si3 - 1) : (s0 < fp->sc ? s0 : 0);

    gp->mi  = mi;
}

static void read_obj(struct mapc_context *ctx, const char *name, int mi)
{
    struct s_base *fp = &ctx->file;
    char line[MAXSTR];
    char mtrl[MAXSTR];
    fs_file fin;

    int v0 = fp->vc;
    int t0 = fp->tc;
    int s0 = fp->sc;

    if ((fin = fs_open_read(name)))
    {
        while (fs_gets(line, MAXSTR, fin))
        {
            if (strncmp(line, "usemtl", 6) == 0)
            {
                sscanf(line + 6, "%s", mtrl);
                mi = read_mtrl(ctx, mtrl);
            }

            else if (strncmp(line, "f", 1) == 0)
            {
                if (fp->mv[mi].d[3] > 0.0f)
                    read_f(ctx, line + 1, v0, t0, s0, mi);
            }

            else if (strncmp(line, "vt", 2) == 0) read_vt(ctx, line + 2);
            else if (strncmp(line, "vn", 2) == 0) read_vn(ctx, line + 2);
            else if (strncmp(line, "v",  1) == 0) read_v (ctx, line + 1);
        }
        fs_close(fin);
    }
}

/*---------------------------------------------------------------------------*/

static void make_plane(struct mapc_context *ctx, int   pi, double x0, double y0, double z0,
                       double x1, double y1, double z1,
                       double x2, double y2, double z2,
                       float tu, float tv, float r,
                       float su, float sv, int   fl, const char *s)
{
    static const float base[6][3][3] = {
        {{  0,  0,  1 }, {  1,  0,  0 }, {  0,  1,  0 }},
        {{  0,  0, -1 }, {  1,  0,  0 }, {  0,  1,  0 }},
        {{  1,  0,  0 }, {  0,  0, -1 }, {  0,  1,  0 }},
        {{ -1,  0,  0 }, {  0,  0, -1 }, {  0,  1,  0 }},
        {{  0,  1,  0 }, {  1,  0,  0 }, {  0,  0, -1 }},
        {{  0, -1,  0 }, {  1,  0,  0 }, {  0,  0, -1 }},
    };

    float R[16];
    double p0[3], p1[3], p2[3];
    double u[3], v[3];
    float p[3];
    float k, d = 0.0f;
    int   i, n = 0;
    int   w, h;

    size_image(ctx, s, &w, &h);

    ctx->plane_f[pi] = fl ? L_DETAIL : 0;

    p0[0] = +x0 / (double) SCALE;
    p0[1] = +z0 / (double) SCALE;
    p0[2] = -y0 / (double) SCALE;

    p1[0] = +x1 / (double) SCALE;
    p1[1] = +z1 / (double) SCALE;
    p1[2] = -y1 / (double) SCALE;

    p2[0] = +x2 / (double) SCALE;
    p2[1] = +z2 / (double) SCALE;
    p2[2] = -y2 / (double) SCALE;

    v_sub(u, p0, p1);
    v_sub(v, p2, p1);

    v_crs(ctx->plane_n[pi], u, v);
    v_nrm_d(ctx->plane_n[pi], ctx->plane_n[pi]);

    ctx->plane_d[pi] = v_dot(ctx->plane_n[pi], p1);

    for (i = 0; i < 6; i++)
        if ((k = v_dot(ctx->plane_n[pi], base[i][0])) >= d)
        {
            d = k;
            n = i;
        }

    p[0] = 0.f;
    p[1] = 0.f;
    p[2] = 0.f;

    /* Always rotate around the positive axis */

    m_rot(R, base[n - (n % 2)][0], V_RAD(r));

    v_mad(p, p, base[n][1], +su * tu / SCALE);
    v_mad(p, p, base[n][2], -sv * tv / SCALE);

    m_vxfm(ctx->plane_u[pi], R, base[n][1]);
    m_vxfm(ctx->plane_v[pi], R, base[n][2]);
    m_vxfm(ctx->plane_p[pi], R, p);

    v_scl(ctx->plane_u[pi], ctx->plane_u[pi], 64.f / w);
    v_scl(ctx->plane_v[pi], ctx->plane_v[pi], 64.f / h);

    v_scl(ctx->plane_u[pi], ctx->plane_u[pi], 1.f / su);
    v_scl(ctx->plane_v[pi], ctx->plane_v[pi], 1.f / sv);
}

/*---------------------------------------------------------------------------*/

#define T_EOF 0
#define T_BEG 1
#define T_CLP 2
#define T_KEY 3
#define T_END 4
#define T_NOP 5

static int map_token(struct mapc_context *ctx, fs_file fin, int pi, char key[MAXSTR], char val[MAXSTR])
{
    char buf[MAXSTR];

    if (fs_gets(buf, MAXSTR, fin))
    {
        double x0, y0, z0;
        double x1, y1, z1;
        double x2, y2, z2;
        float tu, tv, r;
        float su, sv;
        int fl = 0;

        /* Scan the beginning or end of a block. */

        if (buf[0] == '{') return T_BEG;
        if (buf[0] == '}') return T_END;

        /* Scan a key-value pair. */

        if (buf[0] == '\"')
        {
            strcpy(key, strtok(buf,  "\""));
            (void)      strtok(NULL, "\"");
            strcpy(val, strtok(NULL, "\""));

            return T_KEY;
        }

        /* Scan a plane. */

        if (sscanf(buf,
                   "( %lf %lf %lf ) "
                   "( %lf %lf %lf ) "
                   "( %lf %lf %lf ) "
                   "%s %f %f %f %f %f %d",
                   &x0, &y0, &z0,
                   &x1, &y1, &z1,
                   &x2, &y2, &z2,
                   key, &tu, &tv, &r, &su, &sv, &fl) >= 15)
        {
            make_plane(ctx, pi, x0, y0, z0,
                       x1, y1, z1,
                       x2, y2, z2,
                       tu, tv, r, su, sv, fl, key);
            return T_CLP;
        }

        /* If it's not recognized, it must be uninteresting. */

        return T_NOP;
    }
    return T_EOF;
}

/*---------------------------------------------------------------------------*/

/* Parse a lump from the given file and add it to the solid. */

static void read_lump(struct mapc_context *ctx, fs_file fin)
{
    struct s_base *fp = &ctx->file;
    char k[MAXSTR];
    char v[MAXSTR];
    int t;

    struct b_lump *lp = fp->lv + incl(ctx);

    lp->s0 = fp->ic;

    while ((t = map_token(ctx, fin, fp->sc, k, v)))
    {
        if (t == T_CLP)
        {
            fp->sv[fp->sc].n[0] = (float) ctx->plane_n[fp->sc][0];
            fp->sv[fp->sc].n[1] = (float) ctx->plane_n[fp->sc][1];
            fp->sv[fp->sc].n[2] = (float) ctx->plane_n[fp->sc][2];
            fp->sv[fp->sc].d    = (float) ctx->plane_d[fp->sc];

            ctx->plane_m[fp->sc] = read_mtrl(ctx, k);

            fp->iv[fp->ic] = fp->sc;
            inci(ctx);
            incs(ctx);
            lp->sc++;
        }
        if (t == T_END)
            break;
    }
}

/*---------------------------------------------------------------------------*/

static void parse_angles(const char *val, float out_e[4])
{
    static const float X[3] = { 1.0f, 0.0f, 0.0f };
    static const float Y[3] = { 0.0f, 1.0f, 0.0f };
    static const float Z[3] = { 0.0f, 0.0f, 1.0f };

    float x = 0.0f, y = 0.0f, z = 0.0f;
    float d[4], e[4];

    /* Pitch, yaw and roll. */

    sscanf(val, "%f %f %f", &x, &y, &z);

    q_by_axisangle(out_e, Y, V_RAD(+y));

    q_by_axisangle(d, Z, V_RAD(-x));
    q_mul(e, out_e, d);
    q_nrm(out_e, e);

    q_by_axisangle(d, X, V_RAD(+z));
    q_mul(e, out_e, d);
    q_nrm(out_e, e);
}

static void make_path(struct mapc_context *ctx,
                      char k[][MAXSTR],
                      char v[][MAXSTR], int c)
{
    struct s_base *fp = &ctx->file;
    int i, pi = incp(ctx);

    struct b_path *pp = fp->pv + pi;

    pp->p[0] = 0.f;
    pp->p[1] = 0.f;
    pp->p[2] = 0.f;
    pp->t    = 1.f;
    pp->pi   = pi;
    pp->f    = 1;
    pp->s    = 1;

    pp->p0 = pp->p1 = -1;

    for (i = 0; i < c; i++)
    {
        if (strcmp(k[i], "targetname") == 0)
            make_sym(ctx, SYM_PATH, v[i], pi);

        if (strcmp(k[i], "target") == 0 || strcmp(k[i], "target1") == 0)
            make_ref(ctx, SYM_PATH, v[i], &pp->pi);

        if (strcmp(k[i], "target2") == 0)
        {
            make_ref(ctx, SYM_PATH, v[i], &pp->p0);
            pp->fl |= P_PARENTED;
        }

        if (strcmp(k[i], "target3") == 0)
        {
            make_ref(ctx, SYM_PATH, v[i], &pp->p1);
            pp->fl |= P_PARENTED;
        }

        if (strcmp(k[i], "state") == 0)
            pp->f = atoi(v[i]);

        if (strcmp(k[i], "speed") == 0)
            sscanf(v[i], "%f", &pp->t);

        if (strcmp(k[i], "smooth") == 0)
            pp->s = atoi(v[i]);

        if (strcmp(k[i], "origin") == 0)
        {
            float x = 0.f, y = 0.f, z = 0.f;

            sscanf(v[i], "%f %f %f", &x, &y, &z);

            pp->p[0] = +x / SCALE;
            pp->p[1] = +z / SCALE;
            pp->p[2] = -y / SCALE;
        }

        /*
         * Radiant sets "angle" for yaw-only rotations, "angles"
         * otherwise.  Angles takes priority, so check for angle
         * first.
         */

        if (strcmp(k[i], "angle") == 0)
        {
            static const float Y[3] = { 0.0f, 1.0f, 0.0f };

            float y = 0.0f;

            /* Yaw. */

            sscanf(v[i], "%f", &y);
            q_by_axisangle(pp->e, Y, V_RAD(+y));
            pp->fl |= P_ORIENTED;
        }

        if (strcmp(k[i], "angles") == 0)
        {
            parse_angles(v[i], pp->e);
            pp->fl |= P_ORIENTED;
        }
    }
}

static void make_dict(struct mapc_context *ctx,
                      const char *k,
                      const char *v)
{
    struct s_base *fp = &ctx->file;
    int space_left, space_needed, di = incd(ctx);

    struct b_dict *dp = fp->dv + di;

    space_left   = MAXA - fp->ac;
    space_needed = strlen(k) + 1 + strlen(v) + 1;

    if (space_needed > space_left)
    {
        fp->dc--;
        return;
    }

    dp->ai = fp->ac;
    dp->aj = dp->ai + strlen(k) + 1;
    fp->ac = dp->aj + strlen(v) + 1;

    memcpy(fp->av + dp->ai, k, strlen(k) + 1);
    memcpy(fp->av + dp->aj, v, strlen(v) + 1);
}

static void make_body(struct mapc_context *ctx,
                      char k[][MAXSTR],
                      char v[][MAXSTR], int c, int l0)
{
    struct s_base *fp = &ctx->file;
    int i, mi = 0, bi = incb(ctx);

    int g0 = fp->gc;
    int v0 = fp->vc;

    float p[3];

    float x = 0.f;
    float y = 0.f;
    float z = 0.f;

    struct b_body *bp = fp->bv + bi;

    bp->p0 = -1;
    bp->p1 = -1;
    bp->ni = -1;

    for (i = 0; i < c; i++)
    {
        if (strcmp(k[i], "target") == 0 || strcmp(k[i], "target1") == 0)
            make_ref(ctx, SYM_PATH, v[i], &bp->p0);

        else if (strcmp(k[i], "target2") == 0)
            make_ref(ctx, SYM_PATH, v[i], &bp->p1);

        else if (strcmp(k[i], "material") == 0)
            mi = read_mtrl(ctx, v[i]);

        else if (strcmp(k[i], "model") == 0)
            read_obj(ctx, v[i], mi);

        else if (strcmp(k[i], "origin") == 0)
            sscanf(v[i], "%f %f %f", &x, &y, &z);

        else if (ctx->read_dict_entries && strcmp(k[i], "classname") != 0)
            make_dict(ctx, k[i], v[i]);
    }

    bp->l0 = l0;
    bp->lc = fp->lc - l0;
    bp->g0 = fp->ic;
    bp->gc = fp->gc - g0;

    for (i = 0; i < bp->gc; i++)
        fp->iv[inci(ctx)] = g0++;

    p[0] = +x / SCALE;
    p[1] = +z / SCALE;
    p[2] = -y / SCALE;

    for (i = v0; i < fp->vc; i++)
        v_add(fp->vv[i].p, fp->vv[i].p, p);

    ctx->read_dict_entries = 0;
}

static void make_item(struct mapc_context *ctx,
                      char k[][MAXSTR],
                      char v[][MAXSTR], int c)
{
    struct s_base *fp = &ctx->file;
    int i, hi = inch(ctx);

    struct b_item *hp = fp->hv + hi;

    hp->p[0] = 0.f;
    hp->p[1] = 0.f;
    hp->p[2] = 0.f;

    hp->t = ITEM_NONE;
    hp->n = 0;

    hp->p0 = hp->p1 = -1;

    for (i = 0; i < c; i++)
    {
        if (strcmp(k[i], "classname") == 0)
        {
            if (strcmp(v[i], "light") == 0)
                hp->t = ITEM_COIN;
            else if (strcmp(v[i], "item_health_large") == 0)
                hp->t = ITEM_GROW;
            else if (strcmp(v[i], "item_health_small") == 0)
                hp->t = ITEM_SHRINK;
            else if (strcmp(v[i], "item_clock") == 0)
                hp->t = ITEM_CLOCK;
        }

        if (strcmp(k[i], "light") == 0)
            sscanf(v[i], "%d", &hp->n);

        if (strcmp(k[i], "origin") == 0)
        {
            float x = 0.f, y = 0.f, z = 0.f;

            sscanf(v[i], "%f %f %f", &x, &y, &z);

            hp->p[0] = +x / SCALE;
            hp->p[1] = +z / SCALE;
            hp->p[2] = -y / SCALE;
        }

        if (strcmp(k[i], "target") == 0 || strcmp(k[i], "target1") == 0)
            make_ref(ctx, SYM_PATH, v[i], &hp->p0);

        else if (strcmp(k[i], "target2") == 0)
            make_ref(ctx, SYM_PATH, v[i], &hp->p1);

        else if (strcmp(k[i], "angles") == 0)
        {
            parse_angles(v[i], ctx->item_e[hi]);
            ctx->item_has_e[hi] = 1;
        }
    }
}

static void make_bill(struct mapc_context *ctx,
                      char k[][MAXSTR],
                      char v[][MAXSTR], int c)
{
    struct s_base *fp = &ctx->file;
    int i, ri = incr(ctx);

    struct b_bill *rp = fp->rv + ri;

    memset(rp, 0, sizeof (struct b_bill));
    rp->t = 1.0f;

    rp->p0 = rp->p1 = -1;

    for (i = 0; i < c; i++)
    {
        if (strcmp(k[i], "width") == 0)
            sscanf(v[i], "%f %f %f", rp->w, rp->w + 1, rp->w + 2);
        if (strcmp(k[i], "height") == 0)
            sscanf(v[i], "%f %f %f", rp->h, rp->h + 1, rp->h + 2);

        if (strcmp(k[i], "xrot") == 0)
            sscanf(v[i], "%f %f %f", rp->rx, rp->rx + 1, rp->rx + 2);
        if (strcmp(k[i], "yrot") == 0)
            sscanf(v[i], "%f %f %f", rp->ry, rp->ry + 1, rp->ry + 2);
        if (strcmp(k[i], "zrot") == 0)
            sscanf(v[i], "%f %f %f", rp->rz, rp->rz + 1, rp->rz + 2);

        if (strcmp(k[i], "time") == 0)
            sscanf(v[i], "%f", &rp->t);
        if (strcmp(k[i], "dist") == 0)
            sscanf(v[i], "%f", &rp->d);
        if (strcmp(k[i], "flag") == 0)
            sscanf(v[i], "%d", &rp->fl);

        if (strcmp(k[i], "image") == 0)
        {
            rp->mi = read_mtrl(ctx, v[i]);
            fp->mv[rp->mi].fl |= M_CLAMP_S | M_CLAMP_T;
        }

        if (strcmp(k[i], "origin") == 0)
        {
            float x = 0.f, y = 0.f, z = 0.f;

            sscanf(v[i], "%f %f %f", &x, &y, &z);

            rp->p[0] = +x / SCALE;
            rp->p[1] = +z / SCALE;
            rp->p[2] = -y / SCALE;
        }

        if (strcmp(k[i], "target") == 0 || strcmp(k[i], "target1") == 0)
            make_ref(ctx, SYM_PATH, v[i], &rp->p0);

        else if (strcmp(k[i], "target2") == 0)
            make_ref(ctx, SYM_PATH, v[i], &rp->p1);

        else if (strcmp(k[i], "angles") == 0)
        {
            parse_angles(v[i], ctx->bill_e[ri]);
            ctx->bill_has_e[ri] = 1;
        }
    }
}

static void make_goal(struct mapc_context *ctx,
                      char k[][MAXSTR],
                      char v[][MAXSTR], int c, int is_legacy)
{
    struct s_base *fp = &ctx->file;
    int i, zi = incz(ctx);

    struct b_goal *zp = fp->zv + zi;

    zp->p[0] = 0.f;
    zp->p[1] = 0.f;
    zp->p[2] = 0.f;
    zp->r    = 0.75;

    zp->p0 = zp->p1 = -1;
    ctx->goal_is_legacy[zi] = is_legacy;

    for (i = 0; i < c; i++)
    {
        if (strcmp(k[i], "radius") == 0)
            sscanf(v[i], "%f", &zp->r);

        if (strcmp(k[i], "origin") == 0)
        {
            float x = 0.f, y = 0.f, z = 0.f;

            sscanf(v[i], "%f %f %f", &x, &y, &z);

            zp->p[0] = +(x)                     / SCALE;
            zp->p[1] = +(is_legacy ? z - 24 : z) / SCALE;
            zp->p[2] = -(y)                     / SCALE;
        }

        if (strcmp(k[i], "target") == 0 || strcmp(k[i], "target1") == 0)
            make_ref(ctx, SYM_PATH, v[i], &zp->p0);

        else if (strcmp(k[i], "target2") == 0)
            make_ref(ctx, SYM_PATH, v[i], &zp->p1);

        else if (strcmp(k[i], "angles") == 0)
        {
            parse_angles(v[i], ctx->goal_e[zi]);
            ctx->goal_has_e[zi] = 1;
        }
    }

    if (!is_legacy && !ctx->goal_has_e[zi])
    {
        zp->p[1] -= GOAL_HALF_EXTENT / SCALE;
    }
}

static void make_view(struct mapc_context *ctx,
                      char k[][MAXSTR],
                      char v[][MAXSTR], int c)
{
    struct s_base *fp = &ctx->file;
    int i, wi = incw(ctx);

    struct b_view *wp = fp->wv + wi;

    wp->p[0] = 0.f;
    wp->p[1] = 0.f;
    wp->p[2] = 0.f;
    wp->q[0] = 0.f;
    wp->q[1] = 0.f;
    wp->q[2] = 0.f;

    for (i = 0; i < c; i++)
    {
        if (strcmp(k[i], "target") == 0)
            make_ref(ctx, SYM_TARG, v[i], ctx->targ_wi + wi);

        if (strcmp(k[i], "origin") == 0)
        {
            float x = 0.f, y = 0.f, z = 0.f;

            sscanf(v[i], "%f %f %f", &x, &y, &z);

            wp->p[0] = +x / SCALE;
            wp->p[1] = +z / SCALE;
            wp->p[2] = -y / SCALE;
        }
    }
}

static void make_jump(struct mapc_context *ctx,
                      char k[][MAXSTR],
                      char v[][MAXSTR], int c, int is_legacy)
{
    struct s_base *fp = &ctx->file;
    int i, ji = incj(ctx);

    struct b_jump *jp = fp->jv + ji;

    jp->p[0] = 0.f;
    jp->p[1] = 0.f;
    jp->p[2] = 0.f;
    jp->q[0] = 0.f;
    jp->q[1] = 0.f;
    jp->q[2] = 0.f;
    jp->r    = 0.5;

    jp->p0 = jp->p1 = -1;
    ctx->jump_is_legacy[ji] = is_legacy;

    for (i = 0; i < c; i++)
    {
        if (strcmp(k[i], "radius") == 0)
            sscanf(v[i], "%f", &jp->r);

        if (strcmp(k[i], "target") == 0)
            make_ref(ctx, SYM_TARG, v[i], ctx->targ_ji + ji);

        if (strcmp(k[i], "origin") == 0)
        {
            float x = 0.f, y = 0.f, z = 0.f;

            sscanf(v[i], "%f %f %f", &x, &y, &z);

            jp->p[0] = +x / SCALE;
            jp->p[1] = +z / SCALE;
            jp->p[2] = -y / SCALE;
        }

        if (strcmp(k[i], "target2") == 0)
            make_ref(ctx, SYM_PATH, v[i], &jp->p0);

        if (strcmp(k[i], "target3") == 0)
            make_ref(ctx, SYM_PATH, v[i], &jp->p1);

        if (strcmp(k[i], "angles") == 0)
        {
            parse_angles(v[i], ctx->jump_e[ji]);
            ctx->jump_has_e[ji] = 1;
        }
    }

    if (!is_legacy && !ctx->jump_has_e[ji])
    {
        jp->p[1] -= JUMP_HALF_EXTENT / SCALE;
    }
}

static void make_swch(struct mapc_context *ctx,
                      char k[][MAXSTR],
                      char v[][MAXSTR], int c, int is_legacy)
{
    struct s_base *fp = &ctx->file;
    int i, xi = incx(ctx);

    struct b_swch *xp = fp->xv + xi;

    xp->p[0] = 0.f;
    xp->p[1] = 0.f;
    xp->p[2] = 0.f;
    xp->r    = 0.5;
    xp->pi   = 0;
    xp->t    = 0;
    xp->f    = 0;
    xp->i    = 0;

    xp->p0 = xp->p1 = -1;
    ctx->swch_is_legacy[xi] = is_legacy;

    for (i = 0; i < c; i++)
    {
        if (strcmp(k[i], "radius") == 0)
            sscanf(v[i], "%f", &xp->r);

        if (strcmp(k[i], "target") == 0)
            make_ref(ctx, SYM_PATH, v[i], &xp->pi);

        if (strcmp(k[i], "timer") == 0)
            sscanf(v[i], "%f", &xp->t);

        if (strcmp(k[i], "state") == 0)
            xp->f = atoi(v[i]);

        if (strcmp(k[i], "invisible") == 0)
            xp->i = atoi(v[i]);

        if (strcmp(k[i], "origin") == 0)
        {
            float x = 0.f, y = 0.f, z = 0.f;

            sscanf(v[i], "%f %f %f", &x, &y, &z);

            xp->p[0] = +x / SCALE;
            xp->p[1] = +z / SCALE;
            xp->p[2] = -y / SCALE;
        }

        if (strcmp(k[i], "target2") == 0)
            make_ref(ctx, SYM_PATH, v[i], &xp->p0);

        else if (strcmp(k[i], "target3") == 0)
            make_ref(ctx, SYM_PATH, v[i], &xp->p1);

        else if (strcmp(k[i], "angles") == 0)
        {
            parse_angles(v[i], ctx->swch_e[xi]);
            ctx->swch_has_e[xi] = 1;
        }
    }

    if (!is_legacy && !ctx->swch_has_e[xi])
    {
        xp->p[1] -= SWCH_HALF_EXTENT / SCALE;
    }
}

static void make_targ(struct mapc_context *ctx,
                      char k[][MAXSTR],
                      char v[][MAXSTR], int c)
{
    int i;

    ctx->targ_p[ctx->targ_n][0] = 0.f;
    ctx->targ_p[ctx->targ_n][1] = 0.f;
    ctx->targ_p[ctx->targ_n][2] = 0.f;

    for (i = 0; i < c; i++)
    {
        if (strcmp(k[i], "targetname") == 0)
            make_sym(ctx, SYM_TARG, v[i], ctx->targ_n);

        if (strcmp(k[i], "origin") == 0)
        {
            float x = 0.f, y = 0.f, z = 0.f;

            sscanf(v[i], "%f %f %f", &x, &y, &z);

            ctx->targ_p[ctx->targ_n][0] = +x / SCALE;
            ctx->targ_p[ctx->targ_n][1] = +z / SCALE;
            ctx->targ_p[ctx->targ_n][2] = -y / SCALE;
        }
    }

    if (++ctx->targ_n == MAXW)
        overflow(ctx, "target");
}

static void make_ball(struct mapc_context *ctx,
                      char k[][MAXSTR],
                      char v[][MAXSTR], int c, int is_legacy)
{
    struct s_base *fp = &ctx->file;
    int i, ui = incu(ctx);

    struct b_ball *up = fp->uv + ui;

    up->p[0] = 0.0f;
    up->p[1] = 0.0f;
    up->p[2] = 0.0f;
    up->r    = 0.25f;

    for (i = 0; i < c; i++)
    {
        if (strcmp(k[i], "radius") == 0)
            sscanf(v[i], "%f", &up->r);

        if (strcmp(k[i], "origin") == 0)
        {
            float x = 0.f, y = 0.f, z = 0.f;

            sscanf(v[i], "%f %f %f", &x, &y, &z);

            up->p[0] = +(x)                     / SCALE;
            up->p[1] = +(is_legacy ? z - 24 : z) / SCALE;
            up->p[2] = -(y)                     / SCALE;
        }
    }

    if (is_legacy)
        up->p[1] += up->r + SMALL;
}

/*---------------------------------------------------------------------------*/

static void read_ent(struct mapc_context *ctx, fs_file fin)
{
    struct s_base *fp = &ctx->file;
    char k[MAXKEY][MAXSTR];
    char v[MAXKEY][MAXSTR];
    int t, i = 0, c = 0;

    int l0 = fp->lc;

    while ((t = map_token(ctx, fin, -1, k[c], v[c])))
    {
        if (t == T_KEY)
        {
            if (strcmp(k[c], "classname") == 0)
                i = c;
            c++;
        }
        if (t == T_BEG) read_lump(ctx, fin);
        if (t == T_END) break;
    }

    if (!strcmp(v[i], "light"))                    make_item(ctx, k, v, c);
    if (!strcmp(v[i], "item_health_large"))        make_item(ctx, k, v, c);
    if (!strcmp(v[i], "item_health_small"))        make_item(ctx, k, v, c);
    if (!strcmp(v[i], "item_clock"))               make_item(ctx, k, v, c);
    if (!strcmp(v[i], "info_camp"))                make_swch(ctx, k, v, c, 1);
    if (!strcmp(v[i], "game_switch") ||
        !strcmp(v[i], "info_switch"))              make_swch(ctx, k, v, c, 0);
    if (!strcmp(v[i], "info_null"))                make_bill(ctx, k, v, c);
    if (!strcmp(v[i], "path_corner"))              make_path(ctx, k, v, c);
    if (!strcmp(v[i], "info_player_start"))        make_ball(ctx, k, v, c, 1);
    if (!strcmp(v[i], "game_ball") ||
        !strcmp(v[i], "info_ball"))                make_ball(ctx, k, v, c, 0);
    if (!strcmp(v[i], "info_player_intermission")) make_view(ctx, k, v, c);
    if (!strcmp(v[i], "info_player_deathmatch"))   make_goal(ctx, k, v, c, 1);
    if (!strcmp(v[i], "game_goal") ||
        !strcmp(v[i], "info_goal"))                make_goal(ctx, k, v, c, 0);
    if (!strcmp(v[i], "target_teleporter"))        make_jump(ctx, k, v, c, 1);
    if (!strcmp(v[i], "game_jump") ||
        !strcmp(v[i], "info_jump"))                make_jump(ctx, k, v, c, 0);
    if (!strcmp(v[i], "target_position"))          make_targ(ctx, k, v, c);
    if (!strcmp(v[i], "worldspawn"))
    {
        ctx->read_dict_entries = 1;
        make_body(ctx, k, v, c, l0);
    }
    if (!strcmp(v[i], "func_train"))               make_body(ctx, k, v, c, l0);
    if (!strcmp(v[i], "misc_model"))               make_body(ctx, k, v, c, l0);

    /* TrenchBroom compatibility: if func_group has any lumps, add it as a body; ignore otherwise. */

    if (!strcmp(v[i], "func_group") && fp->lc > l0)
        make_body(ctx, k, v, c, l0);
}

static void read_map(struct mapc_context *ctx, fs_file fin)
{
    char k[MAXSTR];
    char v[MAXSTR];
    int t;

    while ((t = map_token(ctx, fin, -1, k, v)))
        if (t == T_BEG)
            read_ent(ctx, fin);
}

/*---------------------------------------------------------------------------*/

/* Test the location of a point with respect to a side plane. */

static void vert_side_add(struct mapc_context *ctx, int vi, int si)
{
    int i;

    for (i = 0; i < ctx->vert_plane_count[vi]; i++)
        if (ctx->vert_planes[vi][i] == si)
            return;

    if (ctx->vert_plane_count[vi] < MAX_VERT_PLANES)
    {
        ctx->vert_planes[vi][ctx->vert_plane_count[vi]] = si;
        ctx->vert_plane_count[vi]++;
        return;
    }

    overflow(ctx, "vertex plane");
}

static int vert_side_test(struct mapc_context *ctx, int vi, int si)
{
    int i;

    for (i = 0; i < ctx->vert_plane_count[vi]; i++)
        if (ctx->vert_planes[vi][i] == si)
            return 1;

    return 0;
}

static int vert_lump_find(const struct s_base *fp,
                          const struct b_lump *lp, const float p[3])
{
    int i;
    for (i = 0; i < lp->vc; i++)
    {
        int vi = fp->iv[lp->v0 + i];
        float *q = fp->vv[vi].p;

        /* Component-wise testing provides an axis-aligned neighborhood for merging. */
        if (fabsf(p[0] - q[0]) < SMALL_VERT &&
            fabsf(p[1] - q[1]) < SMALL_VERT &&
            fabsf(p[2] - q[2]) < SMALL_VERT)
            return vi;
    }
    return -1;
}

/*---------------------------------------------------------------------------*/

/*
 * The following functions take the  set of planes defining a lump and
 * find the verts, edges, and  geoms that describe its boundaries.  To
 * do this, they first find the verts, and then search these verts for
 * valid edges and  geoms.  It may be more  efficient to compute edges
 * and  geoms directly  by clipping  down infinite  line  segments and
 * planes,  but this  would be  more  complex and  prone to  numerical
 * error.
 */

/*
 * Given 3  side planes,  compute the point  of intersection,  if any.
 * Confirm that this point falls  within the current lump, and that it
 * is unique.  Add it as a vert of the solid.
 */
static void clip_vert(struct mapc_context *ctx,
                      struct b_lump *lp, int si, int sj, int sk)
{
    struct s_base *fp = &ctx->file;
    int i;
    double X[9], I[9], d[3], p[3];
    float p3f[3];

    d[0] = ctx->plane_d[si];
    d[1] = ctx->plane_d[sj];
    d[2] = ctx->plane_d[sk];

    X[0] = ctx->plane_n[si][0];
    X[1] = ctx->plane_n[sj][0];
    X[2] = ctx->plane_n[sk][0];

    X[3] = ctx->plane_n[si][1];
    X[4] = ctx->plane_n[sj][1];
    X[5] = ctx->plane_n[sk][1];

    X[6] = ctx->plane_n[si][2];
    X[7] = ctx->plane_n[sj][2];
    X[8] = ctx->plane_n[sk][2];

    if (m_inv3d(I, X))
    {
        m_vxfm3d(p, I, d);

        p3f[0] = (float) p[0];
        p3f[1] = (float) p[1];
        p3f[2] = (float) p[2];

        /*
         * Verify that the generated vertex lies inside the convex lump by
         * testing it against every plane that defines the lump.
         */

        int sls[MAX_VERT_PLANES]; /* Planes this vertex lies on. */
        int slc = 0;

        for (i = 0; i < lp->sc; i++)
        {
            int sl = fp->iv[lp->s0 + i];

            /* The point's distance from the origin along the plane's normal. */
            double pd = v_dot(ctx->plane_n[sl], p);

            /* Short-circuit: if the point is significantly in front of any plane, it's outside the lump. */
            if (pd - ctx->plane_d[sl] > SMALL_CLIP)
                return;

            /* If the point is within clip range from plane, record connectivity. */
            if (fabs(pd - ctx->plane_d[sl]) < SMALL_CLIP)
            {
                if (slc < MAX_VERT_PLANES)
                    sls[slc++] = sl;
                else
                    overflow(ctx, "vertex plane");
            }
        }

        int vi = vert_lump_find(fp, lp, p3f);

        if (vi < 0)
        {
            vi = incv(ctx);
            v_cpy(fp->vv[vi].p, p3f);
            ctx->vert_plane_count[vi] = 0;
            fp->iv[inci(ctx)] = vi;
            lp->vc++;
        }

        for (i = 0; i < slc; i++)
            vert_side_add(ctx, vi, sls[i]);
    }
}

static void clip_edge(struct mapc_context *ctx,
                      struct b_lump *lp, int si, int sj)
{
    struct s_base *fp = &ctx->file;
    int i, j;

    for (i = 1; i < lp->vc; i++)
    {
        int vi = fp->iv[lp->v0 + i];

        if (!vert_side_test(ctx, vi, si) ||
            !vert_side_test(ctx, vi, sj))
            continue;

        for (j = 0; j < i; j++)
        {
            int vj = fp->iv[lp->v0 + j];

            if (vert_side_test(ctx, vj, si) &&
                vert_side_test(ctx, vj, sj))
            {
                fp->ev[fp->ec].vi = vi;
                fp->ev[fp->ec].vj = vj;

                fp->iv[fp->ic] = fp->ec;

                inci(ctx);
                ince(ctx);
                lp->ec++;
            }
        }
    }
}

/*
 * Find all verts that lie on  the given side of the lump.  Sort these
 * verts to  have a counter-clockwise winding about  the plane normal.
 * Create geoms to tessellate the resulting convex polygon.
 */
static void clip_geom(struct mapc_context *ctx,
                      struct b_lump *lp, int si)
{
    struct s_base *fp = &ctx->file;
    int   m[256], t[256], d, i, j, n = 0;
    double u[3], v[3], w[3];

    /* Find em. */

    for (i = 0; i < lp->vc; i++)
    {
        int vi = fp->iv[lp->v0 + i];

        if (vert_side_test(ctx, vi, si))
        {
            float p[3];

            m[n] = vi;
            t[n] = inct(ctx);

            v_add(p, fp->vv[vi].p, ctx->plane_p[si]);

            fp->tv[t[n]].u[0] = v_dot(p, ctx->plane_u[si]);
            fp->tv[t[n]].u[1] = v_dot(p, ctx->plane_v[si]);

            if (++n >= ARRAYSIZE(m))
            {
                ERROR(ctx, "Over 256 vertices on one side, skipping the rest\n");
                break;
            }
        }
    }

    /* Sort em. */

    for (i = 1; i < n; i++)
        for (j = i + 1; j < n; j++)
        {
            double vip[3], vjp[3], v0p[3];

            // Upgrade to double precision to prevent flipped windings.

            v_cpy(vip, fp->vv[m[i]].p);
            v_cpy(vjp, fp->vv[m[j]].p);
            v_cpy(v0p, fp->vv[m[0]].p);

            v_sub(u, vip, v0p);
            v_sub(v, vjp, v0p);

            v_crs(w, u, v);

            if (v_dot(w, ctx->plane_n[si]) < 0.0)
            {
                d     = m[i];
                m[i]  = m[j];
                m[j]  =    d;

                d     = t[i];
                t[i]  = t[j];
                t[j]  =    d;
            }
        }

    /* Index em. */

    for (i = 0; i < n - 2; i++)
    {
        const int gi = incg(ctx);

        struct b_geom *gp = fp->gv + gi;

        struct b_offs *op = fp->ov + (gp->oi = inco(ctx));
        struct b_offs *oq = fp->ov + (gp->oj = inco(ctx));
        struct b_offs *or = fp->ov + (gp->ok = inco(ctx));

        gp->mi = ctx->plane_m[si];

        op->ti = t[0];
        oq->ti = t[i + 1];
        or->ti = t[i + 2];

        op->si = si;
        oq->si = si;
        or->si = si;

        op->vi = m[0];
        oq->vi = m[i + 1];
        or->vi = m[i + 2];

        fp->iv[fp->ic] = gi;
        lp->gc++;
        inci(ctx);
    }
}

/*
 * Iterate the sides of the lump, attempting to generate a new vert for
 * each trio of planes, a new edge  for each pair of planes, and a new
 * set of geom for each visible plane.
 */
static void clip_lump(struct mapc_context *ctx, struct b_lump *lp)
{
    struct s_base *fp = &ctx->file;
    int i, j, k;

    lp->v0 = fp->ic;
    lp->vc = 0;

    for (i = 2; i < lp->sc; i++)
        for (j = 1; j < i; j++)
            for (k = 0; k < j; k++)
                clip_vert(ctx, lp,
                          fp->iv[lp->s0 + i],
                          fp->iv[lp->s0 + j],
                          fp->iv[lp->s0 + k]);

    lp->e0 = fp->ic;
    lp->ec = 0;

    for (i = 1; i < lp->sc; i++)
        for (j = 0; j < i; j++)
            clip_edge(ctx, lp,
                      fp->iv[lp->s0 + i],
                      fp->iv[lp->s0 + j]);

    lp->g0 = fp->ic;
    lp->gc = 0;

    for (i = 0; i < lp->sc; i++)
        if (fp->mv[ctx->plane_m[fp->iv[lp->s0 + i]]].d[3] > 0.0f)
            clip_geom(ctx, lp, fp->iv[lp->s0 + i]);

    for (i = 0; i < lp->sc; i++)
        if (ctx->plane_f[fp->iv[lp->s0 + i]])
            lp->fl |= L_DETAIL;
}

static void clip_file(struct mapc_context *ctx)
{
    struct s_base *fp = &ctx->file;
    int i;

    for (i = 0; i < fp->lc; i++)
        clip_lump(ctx, fp->lv + i);
}

/*---------------------------------------------------------------------------*/

/*
 * For each body element type,  determine if element 'p' is equivalent
 * to element  'q'.  This  is more than  a simple memory  compare.  It
 * effectively  snaps mtrls and  verts together,  and may  reverse the
 * winding of  an edge or a geom.   This is done in  order to maximize
 * the number of elements that can be eliminated.
 */

static int comp_mtrl(const struct b_mtrl *mp, const struct b_mtrl *mq)
{
    if (fabsf(mp->d[0] - mq->d[0]) > SMALL) return 0;
    if (fabsf(mp->d[1] - mq->d[1]) > SMALL) return 0;
    if (fabsf(mp->d[2] - mq->d[2]) > SMALL) return 0;
    if (fabsf(mp->d[3] - mq->d[3]) > SMALL) return 0;

    if (fabsf(mp->a[0] - mq->a[0]) > SMALL) return 0;
    if (fabsf(mp->a[1] - mq->a[1]) > SMALL) return 0;
    if (fabsf(mp->a[2] - mq->a[2]) > SMALL) return 0;
    if (fabsf(mp->a[3] - mq->a[3]) > SMALL) return 0;

    if (fabsf(mp->s[0] - mq->s[0]) > SMALL) return 0;
    if (fabsf(mp->s[1] - mq->s[1]) > SMALL) return 0;
    if (fabsf(mp->s[2] - mq->s[2]) > SMALL) return 0;
    if (fabsf(mp->s[3] - mq->s[3]) > SMALL) return 0;

    if (fabsf(mp->e[0] - mq->e[0]) > SMALL) return 0;
    if (fabsf(mp->e[1] - mq->e[1]) > SMALL) return 0;
    if (fabsf(mp->e[2] - mq->e[2]) > SMALL) return 0;
    if (fabsf(mp->e[3] - mq->e[3]) > SMALL) return 0;

    if (fabsf(mp->h[0] - mq->h[0]) > SMALL) return 0;

    if (strncmp(mp->f, mq->f, PATHMAX)) return 0;

    return 1;
}

static int comp_edge(const struct b_edge *ep, const struct b_edge *eq)
{
    if (ep->vi != eq->vi && ep->vi != eq->vj) return 0;
    if (ep->vj != eq->vi && ep->vj != eq->vj) return 0;

    return 1;
}

static int comp_side(const struct b_side *sp, const struct b_side *sq)
{
    if (sp->d != sq->d) return 0;
    if (v_dot(sp->n, sq->n) < 1.0f) return 0;

    return 1;
}

static int comp_texc(const struct b_texc *tp, const struct b_texc *tq)
{
    if (fabsf(tp->u[0] - tq->u[0]) > SMALL) return 0;
    if (fabsf(tp->u[1] - tq->u[1]) > SMALL) return 0;

    return 1;
}

static int comp_offs(const struct b_offs *op, const struct b_offs *oq)
{
    if (op->ti != oq->ti) return 0;
    if (op->si != oq->si) return 0;
    if (op->vi != oq->vi) return 0;

    return 1;
}

static int comp_geom(const struct b_geom *gp, const struct b_geom *gq)
{
    if (gp->mi != gq->mi) return 0;
    if (gp->oi != gq->oi) return 0;
    if (gp->oj != gq->oj) return 0;
    if (gp->ok != gq->ok) return 0;

    return 1;
}

/*---------------------------------------------------------------------------*/

/*
 * For each file  element type, replace all references  to element 'i'
 * with a  reference to element  'j'.  These are used  when optimizing
 * and sorting the file.
 */

static void swap_mtrl(struct s_base *fp, int mi, int mj)
{
    int i;

    for (i = 0; i < fp->gc; i++)
        if (fp->gv[i].mi == mi) fp->gv[i].mi = mj;
    for (i = 0; i < fp->rc; i++)
        if (fp->rv[i].mi == mi) fp->rv[i].mi = mj;
}

static void swap_vert(struct s_base *fp, int vi, int vj)
{
    int i, j;

    for (i = 0; i < fp->ec; i++)
    {
        if (fp->ev[i].vi == vi) fp->ev[i].vi = vj;
        if (fp->ev[i].vj == vi) fp->ev[i].vj = vj;
    }

    for (i = 0; i < fp->oc; i++)
        if (fp->ov[i].vi == vi) fp->ov[i].vi = vj;

    for (i = 0; i < fp->lc; i++)
        for (j = 0; j < fp->lv[i].vc; j++)
            if (fp->iv[fp->lv[i].v0 + j] == vi)
                fp->iv[fp->lv[i].v0 + j]  = vj;
}

static void apply_mtrl_swaps(struct mapc_context *ctx, struct s_base *fp)
{
    int i;

    for (i = 0; i < fp->gc; i++)
        fp->gv[i].mi = ctx->mtrl_swaps[fp->gv[i].mi];
    for (i = 0; i < fp->rc; i++)
        fp->rv[i].mi = ctx->mtrl_swaps[fp->rv[i].mi];
}

static void apply_edge_swaps(struct mapc_context *ctx, struct s_base *fp)
{
    int i, j;

    for (i = 0; i < fp->lc; i++)
        for (j = 0; j < fp->lv[i].ec; j++)
            fp->iv[fp->lv[i].e0 + j] = ctx->edge_swaps[fp->iv[fp->lv[i].e0 + j]];
}

static void apply_side_swaps(struct mapc_context *ctx, struct s_base *fp)
{
    int i, j;

    for (i = 0; i < fp->oc; i++)
        fp->ov[i].si = ctx->side_swaps[fp->ov[i].si];
    for (i = 0; i < fp->nc; i++)
        fp->nv[i].si = ctx->side_swaps[fp->nv[i].si];

    for (i = 0; i < fp->lc; i++)
        for (j = 0; j < fp->lv[i].sc; j++)
            fp->iv[fp->lv[i].s0 + j] = ctx->side_swaps[fp->iv[fp->lv[i].s0 + j]];
}

static void apply_texc_swaps(struct mapc_context *ctx, struct s_base *fp)
{
    int i;

    for (i = 0; i < fp->oc; i++)
        fp->ov[i].ti = ctx->texc_swaps[fp->ov[i].ti];
}

static void apply_offs_swaps(struct mapc_context *ctx, struct s_base *fp)
{
    int i;

    for (i = 0; i < fp->gc; i++)
    {
        fp->gv[i].oi = ctx->offs_swaps[fp->gv[i].oi];
        fp->gv[i].oj = ctx->offs_swaps[fp->gv[i].oj];
        fp->gv[i].ok = ctx->offs_swaps[fp->gv[i].ok];
    }
}

static void apply_geom_swaps(struct mapc_context *ctx, struct s_base *fp)
{
    int i, j;

    for (i = 0; i < fp->lc; i++)
        for (j = 0; j < fp->lv[i].gc; j++)
            fp->iv[fp->lv[i].g0 + j] = ctx->geom_swaps[fp->iv[fp->lv[i].g0 + j]];

    for (i = 0; i < fp->bc; i++)
        for (j = 0; j < fp->bv[i].gc; j++)
            fp->iv[fp->bv[i].g0 + j] = ctx->geom_swaps[fp->iv[fp->bv[i].g0 + j]];
}

/*---------------------------------------------------------------------------*/

static void uniq_mtrl(struct mapc_context *ctx)
{
    struct s_base *fp = &ctx->file;
    int i, j, k = 0;

    for (i = 0; i < fp->mc; i++)
    {
        for (j = 0; j < k; j++)
            if (comp_mtrl(fp->mv + i, fp->mv + j))
                break;

        ctx->mtrl_swaps[i] = j;

        if (j == k)
        {
            if (i != k)
                fp->mv[k] = fp->mv[i];
            k++;
        }
    }

    apply_mtrl_swaps(ctx, fp);

    fp->mc = k;
}

static void uniq_edge(struct mapc_context *ctx)
{
    struct s_base *fp = &ctx->file;
    int i, j, k = 0;

    for (i = 0; i < fp->ec; i++)
    {
        for (j = 0; j < k; j++)
            if (comp_edge(fp->ev + i, fp->ev + j))
                break;

        ctx->edge_swaps[i] = j;

        if (j == k)
        {
            if (i != k)
                fp->ev[k] = fp->ev[i];
            k++;
        }
    }

    apply_edge_swaps(ctx, fp);

    fp->ec = k;
}

static void uniq_offs(struct mapc_context *ctx)
{
    struct s_base *fp = &ctx->file;
    int i, j, k = 0;

    for (i = 0; i < fp->oc; i++)
    {
        for (j = 0; j < k; j++)
            if (comp_offs(fp->ov + i, fp->ov + j))
                break;

        ctx->offs_swaps[i] = j;

        if (j == k)
        {
            if (i != k)
                fp->ov[k] = fp->ov[i];
            k++;
        }
    }

    apply_offs_swaps(ctx, fp);

    fp->oc = k;
}

static void uniq_geom(struct mapc_context *ctx)
{
    struct s_base *fp = &ctx->file;
    int i, j, k = 0;

    for (i = 0; i < fp->gc; i++)
    {
        for (j = 0; j < k; j++)
            if (comp_geom(fp->gv + i, fp->gv + j))
                break;

        ctx->geom_swaps[i] = j;

        if (j == k)
        {
            if (i != k)
                fp->gv[k] = fp->gv[i];
            k++;
        }
    }

    apply_geom_swaps(ctx, fp);

    fp->gc = k;
}

static void uniq_texc(struct mapc_context *ctx)
{
    struct s_base *fp = &ctx->file;
    int i, j, k = 0;

    for (i = 0; i < fp->tc; i++)
    {
        for (j = 0; j < k; j++)
            if (comp_texc(fp->tv + i, fp->tv + j))
                break;

        ctx->texc_swaps[i] = j;

        if (j == k)
        {
            if (i != k)
                fp->tv[k] = fp->tv[i];
            k++;
        }
    }

    apply_texc_swaps(ctx, fp);

    fp->tc = k;
}

static void uniq_side(struct mapc_context *ctx)
{
    struct s_base *fp = &ctx->file;
    int i, j, k = 0;

    for (i = 0; i < fp->sc; i++)
    {
        for (j = 0; j < k; j++)
            if (comp_side(fp->sv + i, fp->sv + j))
                break;

        ctx->side_swaps[i] = j;

        if (j == k)
        {
            if (i != k)
                fp->sv[k] = fp->sv[i];
            k++;
        }
    }

    apply_side_swaps(ctx, fp);

    fp->sc = k;
}

static void uniq_file(struct mapc_context *ctx)
{
    /* Debug mode skips optimization, producing oversized output files. */

    if (ctx->opt_debug == 0)
    {
        uniq_mtrl(ctx);
        uniq_edge(ctx);
        uniq_texc(ctx);
        uniq_offs(ctx);
        uniq_geom(ctx);
    }
}

/*---------------------------------------------------------------------------*/

struct b_trip
{
    int ci;
    int vi;
    int mi;
    int si;
    int gi;
};

static int comp_trip(const void *p, const void *q)
{
    const struct b_trip *tp = (const struct b_trip *) p;
    const struct b_trip *tq = (const struct b_trip *) q;

    if (tp->ci < tq->ci) return -1;
    if (tp->ci > tq->ci) return +1;
    if (tp->mi < tq->mi) return -1;
    if (tp->mi > tq->mi) return +1;

    return 0;
}

static void smth_file(struct mapc_context *ctx)
{
    struct s_base *fp = &ctx->file;
    struct b_trip temp, *T;

    if (ctx->opt_debug == 0)
    {
        /* Build vertex equivalence map by position. */

        int *canonical_verts = (int *) malloc(fp->vc * sizeof (int));
        int idx;

        if (canonical_verts)
        {
            for (idx = 0; idx < fp->vc; idx++)
            {
                int jdx;

                for (jdx = 0; jdx < idx; jdx++)
                    if (fabsf(fp->vv[idx].p[0] - fp->vv[jdx].p[0]) < SMALL_VERT &&
                        fabsf(fp->vv[idx].p[1] - fp->vv[jdx].p[1]) < SMALL_VERT &&
                        fabsf(fp->vv[idx].p[2] - fp->vv[jdx].p[2]) < SMALL_VERT)
                        break;

                canonical_verts[idx] = jdx;
            }
        }
        else
        {
            overflow(ctx, "canonical vertices");
            return;
        }

        if ((T = (struct b_trip *) malloc(fp->gc * 3 * sizeof (struct b_trip))))
        {
            int gi, i, j, k, l, c = 0;

            /* Create a list of all non-faceted vertex triplets. */

            for (gi = 0; gi < fp->gc; ++gi)
            {
                struct b_geom *gp = fp->gv + gi;

                T[c].vi = fp->ov[gp->oi].vi;
                T[c].si = fp->ov[gp->oi].si;
                T[c].mi = gp->mi;
                T[c].gi = gi;
                T[c].ci = canonical_verts[T[c].vi];
                c++;

                T[c].vi = fp->ov[gp->oj].vi;
                T[c].si = fp->ov[gp->oj].si;
                T[c].mi = gp->mi;
                T[c].gi = gi;
                T[c].ci = canonical_verts[T[c].vi];
                c++;

                T[c].vi = fp->ov[gp->ok].vi;
                T[c].si = fp->ov[gp->ok].si;
                T[c].mi = gp->mi;
                T[c].gi = gi;
                T[c].ci = canonical_verts[T[c].vi];
                c++;
            }

            /* Sort all triplets by vertex index and material. */

            qsort(T, c, sizeof (struct b_trip), comp_trip);

            /* For each set of triplets sharing vertex index and material... */

            for (i = 0; i < c; i = l)
            {
                int acc = 0;

                float N[3], angle = fp->mv[T[i].mi].angle;
                const float   *Ni  = (T[i].si >= 0) ? fp->sv[T[i].si].n : NULL;

                /* Sort the set by side similarity to the first. */

                if (Ni)
                {
                    for (j = i + 1; j < c && (T[j].ci == T[i].ci &&
                                              T[j].mi == T[i].mi); ++j)
                    {
                        for (k = j + 1; k < c && (T[k].ci == T[i].ci &&
                                                  T[k].mi == T[i].mi); ++k)
                        {
                            const float *Nj = fp->sv[T[j].si].n;
                            const float *Nk = fp->sv[T[k].si].n;

                            if (v_dot(Nk, Ni) > v_dot(Nj, Ni))
                            {
                                temp = T[k];
                                T[k] = T[j];
                                T[j] = temp;
                            }
                        }
                    }

                    /* Accumulate all similar side normals. */

                    N[0] = Ni[0];
                    N[1] = Ni[1];
                    N[2] = Ni[2];
                }

                for (l = i + 1; l < c && (T[l].ci == T[i].ci &&
                                           T[l].mi == T[i].mi); ++l)
                {
                    if (Ni && v_dot(fp->sv[T[l].si].n, Ni) < 1.0f)
                    {
                        const float *Nl = fp->sv[T[l].si].n;
                        float deg = V_DEG(facosf(v_dot(Ni, Nl)));

                        if (ROUND(deg * 1000.0f) > ROUND(angle * 1000.0f))
                            break;

                        N[0] += Nl[0];
                        N[1] += Nl[1];
                        N[2] += Nl[2];

                        acc++;
                    }
                }

                /* If at least two normals have been accumulated... */

                if (acc && Ni)
                {
                    /* Store the accumulated normal as a new side. */

                    int ss = incs(ctx);

                    v_nrm(fp->sv[ss].n, N);
                    fp->sv[ss].d = 0.0f;

                    /* Assign the new normal to the merged triplets. */

                    for (j = i; j < l; ++j)
                        T[j].si = ss;
                }
            }

            /* Assign the remapped normals to the original geoms. */

            for (i = 0; i < c; ++i)
            {
                struct b_geom *gp = fp->gv + T[i].gi;
                struct b_offs *op = fp->ov + gp->oi;
                struct b_offs *oq = fp->ov + gp->oj;
                struct b_offs *or = fp->ov + gp->ok;

                if (op->vi == T[i].vi) op->si = T[i].si;
                if (oq->vi == T[i].vi) oq->si = T[i].si;
                if (or->vi == T[i].vi) or->si = T[i].si;
            }

            free(T);
        }

        free(canonical_verts);

        uniq_side(ctx);
        uniq_offs(ctx);
    }
}

/*---------------------------------------------------------------------------*/

static void sort_file(struct mapc_context *ctx)
{
    struct s_base *fp = &ctx->file;
    int i, j, k;

    /* Sort materials by type to minimize state changes. */

    for (i = 1; i < fp->mc; i++)
        for (j = 0, k = 1; j < fp->mc - i; j++, k++)
            if (fp->mv[j].fl > fp->mv[k].fl)
            {
                struct b_mtrl t;

                t         = fp->mv[j];
                fp->mv[j] = fp->mv[k];
                fp->mv[k] =         t;

                swap_mtrl(fp,  j, -1);
                swap_mtrl(fp,  k,  j);
                swap_mtrl(fp, -1,  k);
            }

    /* Sort billboards by material within distance. */

    for (i = 0; i < fp->rc; i++)
        for (j = i + 1; j < fp->rc; j++)
            if ((fp->rv[j].d  > fp->rv[i].d) ||
                (fp->rv[j].d == fp->rv[i].d &&
                 fp->rv[j].mi > fp->rv[i].mi))
            {
                struct b_bill t;

                t         = fp->rv[i];
                fp->rv[i] = fp->rv[j];
                fp->rv[j] =         t;
            }

    /* Sort items by type and value. */

    for (i = 0; i < fp->hc; i++)
        for (j = i + 1; j < fp->hc; j++)
            if ((fp->hv[j].t > fp->hv[i].t) ||
                (fp->hv[j].t == fp->hv[i].t &&
                 fp->hv[j].n > fp->hv[i].n))
            {
                struct b_item t;

                t         = fp->hv[i];
                fp->hv[i] = fp->hv[j];
                fp->hv[j] =         t;
            }

    /* Sort body lumps by flags. */

    for (i = 0; i < fp->bc; i++)
    {
        const struct b_body *bp = &fp->bv[i];

        int li, lj;

        for (li = bp->l0; li < bp->l0 + bp->lc; ++li)
            for (lj = li + 1; lj < bp->l0 + bp->lc; ++lj)
                if (fp->lv[li].fl > fp->lv[lj].fl)
                {
                    struct b_lump t;

                    t          = fp->lv[li];
                    fp->lv[li] = fp->lv[lj];
                    fp->lv[lj] = t;
                }
    }

    /* Ensure the first vertex is the lowest. */

    for (i = 0; i < fp->vc; i++)
        if (fp->vv[0].p[1] > fp->vv[i].p[1])
        {
            struct b_vert t;

            t         = fp->vv[0];
            fp->vv[0] = fp->vv[i];
            fp->vv[i] =         t;

            swap_vert(fp,  0, -1);
            swap_vert(fp,  i,  0);
            swap_vert(fp, -1,  i);
        }
}

/*---------------------------------------------------------------------------*/

static int test_lump_side(const struct s_base *fp,
                          const struct b_lump *lp,
                          const struct b_side *sp,
                          float bsphere[4])
{
    int si;
    int vi;

    int f = 0;
    int b = 0;

    float d;

    if (!lp->vc)
        return 0;

    /* Check if the bounding sphere of the lump is completely on one side. */

    d = v_dot(bsphere, sp->n) - sp->d;

    if (fabsf(d) > bsphere[3])
        return d > 0 ? 1 : -1;

    /* If the given side is part of the given lump, then the lump is behind. */

    for (si = 0; si < lp->sc; si++)
        if (fp->sv + fp->iv[lp->s0 + si] == sp)
            return -1;

    /* Check if each lump vertex is in front of, behind, on the side. */

    for (vi = 0; vi < lp->vc; vi++)
    {
        d = v_dot(fp->vv[fp->iv[lp->v0 + vi]].p, sp->n) - sp->d;

        if (d > +SMALL_NODE) f++;
        if (d < -SMALL_NODE) b++;
    }

    /* If no verts are behind, the lump is in front, and vice versa. */

    if (f > 0 && b == 0) return +1;
    if (b > 0 && f == 0) return -1;

    /* Else, the lump crosses the side. */

    return 0;
}

static int node_node(struct mapc_context *ctx, int l0, int lc, float bsphere[][4])
{
    struct s_base *fp = &ctx->file;

    if (lc < 8)
    {
        /* Base case.  Dump all given lumps into a leaf node. */

        fp->nv[fp->nc].si = -1;
        fp->nv[fp->nc].ni = -1;
        fp->nv[fp->nc].nj = -1;
        fp->nv[fp->nc].l0 = l0;
        fp->nv[fp->nc].lc = lc;

        return incn(ctx);
    }
    else
    {
        int sj  = 0;
        int sjd = lc;
        int sjo = lc;
        int si;
        int li = 0, lic = 0;
        int lj = 0, ljc = 0;
        int lk = 0, lkc = 0;
        int i;

        /* Find the side that most evenly splits the given lumps. */

        for (si = 0; si < fp->sc; si++)
        {
            int o = 0;
            int d = 0;
            int k = 0;

            for (li = 0; li < lc; li++)
                if ((k = test_lump_side(fp,
                                        fp->lv + l0 + li,
                                        fp->sv + si,
                                        bsphere[l0 + li])))
                    d += k;
                else
                    o++;

            d = abs(d);

            if ((d < sjd) || (d == sjd && o < sjo))
            {
                sj  = si;
                sjd = d;
                sjo = o;
            }
        }

        /* Flag each lump with its position WRT the side. */

        for (li = 0; li < lc; li++)
            if (ctx->opt_debug)
            {
                fp->lv[l0+li].fl = (fp->lv[l0+li].fl & 1) | 0x20;
            }
            else
            {
                switch (test_lump_side(fp,
                                       fp->lv + l0 + li,
                                       fp->sv + sj,
                                       bsphere[l0 + li]))
                {
                case +1:
                    fp->lv[l0+li].fl = (fp->lv[l0+li].fl & 1) | 0x10;
                    break;

                case  0:
                    fp->lv[l0+li].fl = (fp->lv[l0+li].fl & 1) | 0x20;
                    break;

                case -1:
                    fp->lv[l0+li].fl = (fp->lv[l0+li].fl & 1) | 0x40;
                    break;
                }
            }

        /* Sort all lumps in the range by their flag values. */

        for (li = 1; li < lc; li++)
            for (lj = 0; lj < li; lj++)
                if (fp->lv[l0 + li].fl < fp->lv[l0 + lj].fl)
                {
                    struct b_lump l;
                    float f;

                    for (i = 0; i < 4; i++)
                    {
                        f                   = bsphere[l0 + li][i];
                        bsphere[l0 + li][i] = bsphere[l0 + lj][i];
                        bsphere[l0 + lj][i] =                   f;
                    }

                    l               = fp->lv[l0 + li];
                    fp->lv[l0 + li] = fp->lv[l0 + lj];
                    fp->lv[l0 + lj] =               l;
                }

        /* Establish the in-front, on, and behind lump ranges. */

        li = lic = 0;
        lj = ljc = 0;
        lk = lkc = 0;

        for (i = lc - 1; i >= 0; i--)
            switch (fp->lv[l0 + i].fl & 0xf0)
            {
            case 0x10: li = l0 + i; lic++; break;
            case 0x20: lj = l0 + i; ljc++; break;
            case 0x40: lk = l0 + i; lkc++; break;
            }

        /* Add the lumps on the side to the node. */

        i = incn(ctx);

        fp->nv[i].si = sj;
        fp->nv[i].ni = node_node(ctx, li, lic, bsphere);

        fp->nv[i].nj = node_node(ctx, lk, lkc, bsphere);
        fp->nv[i].l0 = lj;
        fp->nv[i].lc = ljc;

        return i;
    }
}

/*
 * Compute a bounding sphere for a lump (not optimal)
 */
static void lump_bounding_sphere(struct s_base *fp,
                                 struct b_lump *lp,
                                 float bsphere[4])
{
    float bbox[6];
    float r;
    int i;

    if (!lp->vc)
        return;

    bbox[0] = bbox[3] = fp->vv[fp->iv[lp->v0]].p[0];
    bbox[1] = bbox[4] = fp->vv[fp->iv[lp->v0]].p[1];
    bbox[2] = bbox[5] = fp->vv[fp->iv[lp->v0]].p[2];

    for (i = 1; i < lp->vc; i++)
    {
        struct b_vert *vp = fp->vv + fp->iv[lp->v0 + i];
        int j;

        for (j = 0; j < 3; j++)
            if (vp->p[j] < bbox[j])
                bbox[j] = vp->p[j];

        for (j = 0; j < 3; j++)
            if (vp->p[j] > bbox[j + 3])
                bbox[j + 3] = vp->p[j];
    }

    r = 0;

    for (i = 0; i < 3; i++)
    {
        bsphere[i] = (bbox[i] + bbox[i + 3]) / 2;
        r += (bsphere[i] - bbox[i]) * (bsphere[i] - bbox[i]);
    }

    bsphere[3] = fsqrtf(r);
}

static void node_file(struct mapc_context *ctx)
{
    struct s_base *fp = &ctx->file;
    static float bsphere[MAXL][4];
    int i;

    /* Compute a bounding sphere for each lump. */

    for (i = 0; i < fp->lc; i++)
        if (fp->lv[i].fl == 0)
            lump_bounding_sphere(fp, fp->lv + i, bsphere[i]);

    for (i = 0; i < fp->bc; i++)
    {
        int lc;

        /* Count solid lumps. This assumes lumps have been sorted by flags. */

        for (lc = 0; lc < fp->bv[i].lc; lc++)
            if (fp->lv[fp->bv[i].l0 + lc].fl != 0)
                break;

        /* Sort the solid lumps of each body into BSP nodes. */

        fp->bv[i].ni = node_node(ctx, fp->bv[i].l0, lc, bsphere);
    }
}

/*---------------------------------------------------------------------------*/

struct dump_stats
{
    size_t off;
    char name[5];
    char desc[32];
    int *ptr;
};

/*
 * This initializer looked a lot better in the C99 version.
 */
static struct dump_stats stats[] = {
    { offsetof (struct s_base, mc), "mtrl", "materials" },
    { offsetof (struct s_base, vc), "vert", "vertices" },
    { offsetof (struct s_base, ec), "edge", "edges" },
    { offsetof (struct s_base, sc), "side", "sides" },
    { offsetof (struct s_base, tc), "texc", "texcoords" },
    { offsetof (struct s_base, oc), "offs", "offsets" },
    { offsetof (struct s_base, gc), "geom", "geoms" },
    { offsetof (struct s_base, lc), "lump", "lumps" },
    { offsetof (struct s_base, pc), "path", "paths" },
    { offsetof (struct s_base, nc), "node", "nodes" },
    { offsetof (struct s_base, bc), "body", "bodies" },
    { offsetof (struct s_base, hc), "item", "items" },
    { offsetof (struct s_base, zc), "goal", "goals" },
    { offsetof (struct s_base, wc), "view", "viewpoints" },
    { offsetof (struct s_base, jc), "jump", "teleports" },
    { offsetof (struct s_base, xc), "swch", "switches" },
    { offsetof (struct s_base, rc), "bill", "billboards" },
    { offsetof (struct s_base, uc), "ball", "balls" },
    { offsetof (struct s_base, ac), "char", "chars" },
    { offsetof (struct s_base, dc), "dict", "dicts" },
    { offsetof (struct s_base, ic), "indx", "indices" }
};

static void dump_init(struct s_base *fp)
{
    int i;

    for (i = 0; i < ARRAYSIZE(stats); i++)
        stats[i].ptr = (int *) &((unsigned char *) fp)[stats[i].off];
}

void mapc_dump(struct mapc_context *ctx)
{
    const char *name = CSTR(ctx->dst_path);
    double t = ctx->compile_time;

    struct s_base *p = &ctx->file;
    int i, j;
    int c = 0;
    int n = 0;

    dump_init(p);

    /* Count the number of solid lumps. */

    for (i = 0; i < p->lc; i++)
        if ((p->lv[i].fl & 1) == 0)
            n++;

    /* Count the total value of all coins. */

    for (i = 0; i < p->hc; i++)
        if (p->hv[i].t == ITEM_COIN)
            c += p->hv[i].n;

#if ENABLE_RADIANT_CONSOLE
    if (ctx->bcast_socket)
    {
        char msg[512];
        char buf[64];

        sprintf(msg, "%s (%d/$%d) %.3f\n", name, n, c, t);

        for (i = 0; i < ARRAYSIZE(stats); i++)
        {
            sprintf(buf, "\t%d %s\n", *stats[i].ptr, stats[i].desc);
            SAFECAT(msg, buf);
        }

        bcast_send_msg(ctx, BCAST_STD, msg);
    }
#endif

    if (ctx->opt_csv)
    {
        printf("file,n,c,t,");

        for (i = 0; i < ARRAYSIZE(stats); i++)
            printf("%s%s", stats[i].name, (i + 1 < ARRAYSIZE(stats) ?
                                           "," : "\n"));
        printf("%s,%d,%d,%.3f,", name, n, c, t);

        for (i = 0; i < ARRAYSIZE(stats); i++)
            printf("%d%s", *stats[i].ptr, (i + 1 < ARRAYSIZE(stats) ?
                                           "," : "\n"));
    }
    else
    {
        const int COLS = 11;

        printf("%s (%d/$%d) %.3f\n", name, n, c, t);

        for (i = 0, j = 0; i < ARRAYSIZE(stats); i++)
        {
            printf("%6.6s", stats[i].name);

            if ((i + 1) % COLS == 0 || i + 1 == ARRAYSIZE(stats))
            {
                printf("\n");

                for (; j <= i; j++)
                    printf("%6d", *stats[j].ptr);

                printf("\n");
            }
        }
    }
}

/*---------------------------------------------------------------------------*/

void mapc_set_src(struct mapc_context *ctx, const char *src)
{
    ctx->src_path = strbuf(src);
}

void mapc_set_dst(struct mapc_context *ctx, const char *dst)
{
    ctx->dst_path = strbuf(dst);
}

struct s_base *mapc_get_base(struct mapc_context *ctx)
{
    return &ctx->file;
}

/*---------------------------------------------------------------------------*/

int mapc_opts(struct mapc_context *ctx, int argc, char *argv[])
{
    int argi;

    for (argi = 1; argi < argc; ++argi)
    {
        if (strcmp(argv[argi], "--debug") == 0)
        {
            ctx->opt_debug = 1;
        }
        else if (strcmp(argv[argi], "--csv")   == 0)
        {
            ctx->opt_csv = 1;
            fs_set_logging(0);
        }
        else if (strcmp(argv[argi], "--bcast") == 0)
        {
#if ENABLE_RADIANT_CONSOLE
            bcast_init(ctx);
#endif
        }
        else if (strcmp(argv[argi], "--data")  == 0)
        {
            if (++argi < argc)
                fs_add_path(argv[argi]);
        }
        else if (!ctx->opt_file)
        {
            ctx->opt_file = argv[argi];

            ctx->src_path = strbuf(ctx->opt_file);

            if (str_ends_with(ctx->opt_file, ".map"))
            {
                STRBUF name_part = substr(ctx->opt_file, 0, strlen(ctx->opt_file) - 4u);
                ctx->dst_path = joinstr(CSTR(name_part), ".sol");
            }
            else
                ctx->dst_path = joinstr(ctx->opt_file, ".sol");

            STRBUF src_dir = dir_name_strbuf(CSTR(ctx->src_path));
            fs_add_path(CSTR(src_dir));

            STRBUF dst_dir = dir_name_strbuf(CSTR(ctx->dst_path));
            fs_set_write_dir(CSTR(dst_dir));

            // Save the full path for the dump.

            ctx->full_dst_path = ctx->dst_path;

            ctx->src_path = base_name_strbuf(CSTR(ctx->src_path));
            ctx->dst_path = base_name_strbuf(CSTR(ctx->dst_path));
        }
        else if (!ctx->opt_data)
        {
            ctx->opt_data = argv[argi];

            fs_add_path_with_archives(ctx->opt_data);
        }
        else
            fprintf(stderr, "Unknown option: %s\n", argv[argi]);
    }

    if (!(ctx->opt_file && ctx->opt_data))
    {
        fprintf(stderr, "Usage: %s <map> <data> [--debug] [--csv] [--data <dir>]\n", argv[0]);
        return 0;
    }

    return 1;
}

static void calc_cylinder_pos(float p[3], const float e[4], float extent)
{
    float local_down[3] = { 0.0f, -extent / SCALE, 0.0f };
    float world_offset[3];

    q_rot(world_offset, e, local_down);
    v_add(p, p, world_offset);
}

/*
 * Synthesize a stationary child orientation path node (P_PARENTED | P_ORIENTED)
 * linked to the parent mover at p0, and transform the entity's initial world
 * position into the local reference frame of the parent body.
 */
static void make_parented_path(struct mapc_context *ctx,
                               float p[3], int p0, int *p1, const float e[4])
{
    struct s_base *fp = &ctx->file;
    float inv_e[4], d[3];

    int pi = incp(ctx);
    struct b_path *pp = fp->pv + pi;
    memset(pp, 0, sizeof (*pp));
    pp->pi = pi;
    pp->t  = 1.0f;
    pp->f  = 1;
    pp->s  = 1;
    pp->p0 = p0;
    pp->p1 = p0;
    pp->fl |= P_PARENTED | P_ORIENTED;
    q_cpy(pp->e, e);
    *p1 = pi;

    if (p)
    {
        v_sub(d, p, fp->pv[p0].p);
        q_conj(inv_e, e);
        q_rot(d, inv_e, d);
        v_add(p, fp->pv[p0].p, d);
    }
}

static const char *get_sym_name(const struct mapc_context *ctx, int type, int val)
{
    int i;
    for (i = 0; i < ctx->symc; i++)
        if (ctx->syms[i].type == type && ctx->syms[i].val == val)
            return ctx->syms[i].name;
    return NULL;
}

static void check_oriented_path(struct mapc_context *ctx, int p0, int has_angles)
{
    struct s_base *fp = &ctx->file;

    if (p0 >= 0 && (fp->pv[p0].fl & P_ORIENTED))
    {
        char buf[MAXSTR];
        const char *name = get_sym_name(ctx, SYM_PATH, p0);

        SAFECPY(buf, ctx->opt_file ? ctx->opt_file : "mapc");
        if (has_angles)
            SAFECAT(buf, ": warning: entity with angles connected to oriented path");
        else
            SAFECAT(buf, ": warning: entity connected to path node with initial angles");

        if (name && *name)
        {
            SAFECAT(buf, " \"");
            SAFECAT(buf, name);
            SAFECAT(buf, "\"");
        }
        SAFECAT(buf, " (in-game orientation will differ from editor)\n");
        WARNING(ctx, buf);
    }
}

/*
 * Synthesize a stationary unparented orientation path node (P_ORIENTED)
 * holding a constant orientation e for an unmoving entity.
 */
static void make_stationary_path(struct mapc_context *ctx,
                                 const float p[3], int *p0, int *p1, const float e[4])
{
    struct s_base *fp = &ctx->file;

    int pi = incp(ctx);
    struct b_path *pp = fp->pv + pi;
    memset(pp, 0, sizeof (*pp));
    pp->pi = pi;
    pp->t  = 1.0f;
    pp->f  = 1;
    pp->s  = 1;
    pp->p0 = -1;
    pp->p1 = -1;
    pp->fl |= P_ORIENTED;
    v_cpy(pp->p, p);
    q_cpy(pp->e, e);
    *p0 = pi;
    *p1 = pi;
}

/*
 * Synthesize an orientation path node for an angled entity if no explicit
 * rotation path (p1) was already assigned.
 */
static void turn_entity(struct mapc_context *ctx,
                        float p[3], int *p0, int *p1, const float e[4])
{
    if (*p0 >= 0 && *p1 < 0)
        make_parented_path(ctx, p, *p0, p1, e);
    else if (*p0 < 0 && *p1 < 0)
        make_stationary_path(ctx, p, p0, p1, e);
}

static void turn_file(struct mapc_context *ctx)
{
    struct s_base *fp = &ctx->file;
    int i;

    /* Bodies (func_train) */
    for (i = 0; i < fp->bc; i++)
        if (fp->bv[i].p0 >= 0)
            check_oriented_path(ctx, fp->bv[i].p0, 0);

    /* Items */
    for (i = 0; i < fp->hc; i++)
    {
        if (fp->hv[i].p0 >= 0)
            check_oriented_path(ctx, fp->hv[i].p0, ctx->item_has_e[i]);
        if (ctx->item_has_e[i])
            turn_entity(ctx, fp->hv[i].p, &fp->hv[i].p0, &fp->hv[i].p1, ctx->item_e[i]);
    }

    /* Goals */
    for (i = 0; i < fp->zc; i++)
    {
        if (fp->zv[i].p0 >= 0)
            check_oriented_path(ctx, fp->zv[i].p0, ctx->goal_has_e[i]);
        if (ctx->goal_has_e[i])
        {
            if (!ctx->goal_is_legacy[i])
                calc_cylinder_pos(fp->zv[i].p, ctx->goal_e[i], GOAL_HALF_EXTENT);

            turn_entity(ctx, fp->zv[i].p, &fp->zv[i].p0, &fp->zv[i].p1, ctx->goal_e[i]);
        }
    }

    /* Teleporters */
    for (i = 0; i < fp->jc; i++)
    {
        if (fp->jv[i].p0 >= 0)
            check_oriented_path(ctx, fp->jv[i].p0, ctx->jump_has_e[i]);
        if (ctx->jump_has_e[i])
        {
            if (!ctx->jump_is_legacy[i])
                calc_cylinder_pos(fp->jv[i].p, ctx->jump_e[i], JUMP_HALF_EXTENT);

            turn_entity(ctx, fp->jv[i].p, &fp->jv[i].p0, &fp->jv[i].p1, ctx->jump_e[i]);
        }
    }

    /* Switches */
    for (i = 0; i < fp->xc; i++)
    {
        if (fp->xv[i].p0 >= 0)
            check_oriented_path(ctx, fp->xv[i].p0, ctx->swch_has_e[i]);
        if (ctx->swch_has_e[i])
        {
            if (!ctx->swch_is_legacy[i])
                calc_cylinder_pos(fp->xv[i].p, ctx->swch_e[i], SWCH_HALF_EXTENT);

            turn_entity(ctx, fp->xv[i].p, &fp->xv[i].p0, &fp->xv[i].p1, ctx->swch_e[i]);
        }
    }

    /* Billboards */
    for (i = 0; i < fp->rc; i++)
    {
        if (fp->rv[i].p0 >= 0)
            check_oriented_path(ctx, fp->rv[i].p0, ctx->bill_has_e[i]);
        if (ctx->bill_has_e[i])
            turn_entity(ctx, fp->rv[i].p, &fp->rv[i].p0, &fp->rv[i].p1, ctx->bill_e[i]);
    }
}

/*---------------------------------------------------------------------------*/

static void mapc_compile_internal(struct mapc_context *ctx)
{
    const char *src = CSTR(ctx->src_path);
    const char *dst = CSTR(ctx->dst_path);

    struct timeval time0, time1;

    gettimeofday(&time0, 0);
    {
        fs_file fin;

        if ((fin = fs_open_read(src)))
        {
            read_map(ctx, fin);
            fs_close(fin);
            fin = NULL;
        }
        else
        {
            ERROR(ctx, "Failure to open file\n");
            longjmp(ctx->jmpbuf, MAPC_ERROR);
            return;
        }

        resolve(ctx);
        targets(ctx);

        turn_file(ctx);
        clip_file(ctx);
        move_file(ctx);
        uniq_file(ctx);
        smth_file(ctx);
        sort_file(ctx);
        node_file(ctx);

        if (dst && *dst)
            sol_stor_base(&ctx->file, dst);
    }
    gettimeofday(&time1, 0);

    ctx->compile_time = (time1.tv_sec  - time0.tv_sec) +
                        (time1.tv_usec - time0.tv_usec) / 1000000.0;
}

int mapc_compile(struct mapc_context *ctx)
{
    if (setjmp(ctx->jmpbuf) == MAPC_SUCCESS)
    {
        mapc_compile_internal(ctx);

        return 1;
    }

    return 0;
}

/*---------------------------------------------------------------------------*/
